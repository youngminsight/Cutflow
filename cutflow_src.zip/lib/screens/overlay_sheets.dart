import 'package:flutter/material.dart';

import '../logic/editor_state.dart';
import '../logic/models.dart';

const List<String> kEmojis = <String>[
  '😀', '😂', '😍', '🔥', '👍', '🎉', '❤️', '⭐', '😎', '🙌',
  '💯', '✨', '🎵', '📸', '🌍', '🌈', '🙏', '😢', '😡', '🤔',
  '🥳', '💪', '👏', '🏆', '🎬', '🍕', '⚽', '🚗', '🌟', '💥',
  '😴', '🤩', '😜', '🕺', '💃', '👑', '🎁', '🌹', '☀️', '🌙',
];

const List<int> kTextColors = <int>[
  0xFFFFFFFF,
  0xFFFFEB3B,
  0xFF22D3EE,
  0xFFFF80AB,
  0xFF69F0AE,
  0xFF000000,
];

String _time(int ms) {
  final int total = (ms / 1000).round();
  final int m = total ~/ 60;
  final int s = total % 60;
  return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
}

Future<String?> askText(BuildContext context, {String initial = ''}) {
  final TextEditingController controller = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (BuildContext ctx) => AlertDialog(
      title: Text(initial.isEmpty ? 'Add text' : 'Edit text'),
      content: TextField(
        controller: controller,
        autofocus: true,
        minLines: 1,
        maxLines: 3,
        decoration: const InputDecoration(hintText: 'Type your text'),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, controller.text),
          child: Text(initial.isEmpty ? 'Add' : 'Save'),
        ),
      ],
    ),
  );
}

Future<String?> pickSticker(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    builder: (BuildContext ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: GridView.count(
          shrinkWrap: true,
          crossAxisCount: 6,
          children: <Widget>[
            for (final String e in kEmojis)
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => Navigator.pop(ctx, e),
                child: Center(
                  child: Text(e, style: const TextStyle(fontSize: 30)),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

/// Edit one text or sticker: words, colour, size and when it shows.
class OverlayEditorSheet extends StatefulWidget {
  const OverlayEditorSheet({super.key, required this.state, required this.id});

  final EditorState state;
  final String id;

  @override
  State<OverlayEditorSheet> createState() => _OverlayEditorSheetState();
}

class _OverlayEditorSheetState extends State<OverlayEditorSheet> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(
      text: widget.state.overlayById(widget.id)?.text ?? '',
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: widget.state,
      builder: (BuildContext context, Widget? child) {
        final ClipOverlay? o = widget.state.overlayById(widget.id);
        if (o == null) return const SizedBox(height: 80);
        final int total =
            widget.state.totalOutputMs < 1000 ? 1000 : widget.state.totalOutputMs;
        final bool isText = o.kind == OverlayKind.text;
        return SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              20,
              0,
              20,
              20 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  isText ? 'Edit text' : 'Edit sticker',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                if (isText) ...<Widget>[
                  TextField(
                    controller: _controller,
                    minLines: 1,
                    maxLines: 3,
                    onChanged: (String v) {
                      if (v.trim().isNotEmpty) {
                        widget.state.updateOverlay(o.copyWith(text: v));
                      }
                    },
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 10,
                    children: <Widget>[
                      for (final int c in kTextColors)
                        GestureDetector(
                          onTap: () =>
                              widget.state.updateOverlay(o.copyWith(colorValue: c)),
                          child: Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: Color(c),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: o.colorValue == c
                                    ? theme.colorScheme.primary
                                    : Colors.white24,
                                width: o.colorValue == c ? 3 : 1,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                ],
                Text('Size', style: theme.textTheme.titleSmall),
                Slider(
                  min: 0.03,
                  max: 0.25,
                  value: o.sizeFrac.clamp(0.03, 0.25).toDouble(),
                  onChanged: (double v) =>
                      widget.state.updateOverlay(o.copyWith(sizeFrac: v)),
                ),
                Text(
                  'Shows from ${_time(o.startMs)} to ${_time(o.endMs)}',
                  style: theme.textTheme.titleSmall,
                ),
                RangeSlider(
                  min: 0,
                  max: total.toDouble(),
                  values: RangeValues(
                    o.startMs.clamp(0, total).toDouble(),
                    o.endMs.clamp(0, total).toDouble(),
                  ),
                  onChanged: (RangeValues v) {
                    final int s = v.start.round();
                    final int e = v.end.round();
                    if (e - s < 300) return;
                    widget.state.updateOverlay(o.copyWith(startMs: s, endMs: e));
                  },
                ),
                Text(
                  'Drag it on the video to move it.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          widget.state.deleteOverlay(o.id);
                          Navigator.pop(context);
                        },
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('Delete'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Done'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Edit one music or voice-over track: volume and start time.
class TrackEditorSheet extends StatelessWidget {
  const TrackEditorSheet({super.key, required this.state, required this.id});

  final EditorState state;
  final String id;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        final AudioTrack? t = state.trackById(id);
        if (t == null) return const SizedBox(height: 80);
        final int total =
            state.totalOutputMs < 1000 ? 1000 : state.totalOutputMs;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  t.kind == TrackKind.music ? 'Music' : 'Voice-over',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                Text(t.label, maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 12),
                Text('Volume ${(t.volume * 100).round()}%',
                    style: theme.textTheme.titleSmall),
                Slider(
                  min: 0,
                  max: 2,
                  value: t.volume.clamp(0.0, 2.0).toDouble(),
                  onChanged: (double v) =>
                      state.updateTrack(t.copyWith(volume: v)),
                ),
                Text('Starts at ${_time(t.startMs)}',
                    style: theme.textTheme.titleSmall),
                Slider(
                  min: 0,
                  max: total.toDouble(),
                  value: t.startMs.clamp(0, total).toDouble(),
                  onChanged: (double v) =>
                      state.updateTrack(t.copyWith(startMs: v.round())),
                ),
                const SizedBox(height: 8),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          state.deleteTrack(t.id);
                          Navigator.pop(context);
                        },
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('Delete'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Done'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Volume of the original sound in the videos.
class SoundSheet extends StatelessWidget {
  const SoundSheet({super.key, required this.state});

  final EditorState state;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Original sound',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text('Volume ${(state.originalVolume * 100).round()}%'),
                Slider(
                  min: 0,
                  max: 1.5,
                  value: state.originalVolume.clamp(0.0, 1.5).toDouble(),
                  onChanged: state.setOriginalVolume,
                ),
                Wrap(
                  spacing: 8,
                  children: <Widget>[
                    ActionChip(
                      label: const Text('Mute'),
                      onPressed: () => state.setOriginalVolume(0),
                    ),
                    ActionChip(
                      label: const Text('Reset to 100%'),
                      onPressed: () => state.setOriginalVolume(1),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Music and voice-overs are mixed in when you export. '
                  'They do not play in this preview.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}


/// Edit one picture-in-picture photo or video: size and when it shows.
class LayerEditorSheet extends StatelessWidget {
  const LayerEditorSheet({super.key, required this.state, required this.id});

  final EditorState state;
  final String id;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        final PipLayer? l = state.layerById(id);
        if (l == null) return const SizedBox(height: 80);
        final int total =
            state.totalOutputMs < 1000 ? 1000 : state.totalOutputMs;
        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  l.isVideo ? 'Video layer' : 'Photo layer',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                Text('Size', style: theme.textTheme.titleSmall),
                Slider(
                  min: 0.1,
                  max: 0.9,
                  value: l.widthFrac.clamp(0.1, 0.9).toDouble(),
                  onChanged: (double v) =>
                      state.updateLayer(l.copyWith(widthFrac: v)),
                ),
                Text(
                  'Shows from ${_time(l.startMs)} to ${_time(l.endMs)}',
                  style: theme.textTheme.titleSmall,
                ),
                RangeSlider(
                  min: 0,
                  max: total.toDouble(),
                  values: RangeValues(
                    l.startMs.clamp(0, total).toDouble(),
                    l.endMs.clamp(0, total).toDouble(),
                  ),
                  onChanged: (RangeValues v) {
                    final int s = v.start.round();
                    final int e = v.end.round();
                    if (e - s < 300) return;
                    state.updateLayer(l.copyWith(startMs: s, endMs: e));
                  },
                ),
                Text(
                  l.isVideo
                      ? 'Drag it on the video to move it. In the preview a video layer shows as a box. Its own sound is not used.'
                      : 'Drag it on the video to move it.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          state.deleteLayer(l.id);
                          Navigator.pop(context);
                        },
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('Delete'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Done'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

typedef CaptionGenerator = Future<void> Function(
  bool better,
  void Function(String status, double? progress) report,
);

/// Make English captions from the speech, then fix, restyle or remove them.
class CaptionsSheet extends StatefulWidget {
  const CaptionsSheet({super.key, required this.state, required this.generate});

  final EditorState state;
  final CaptionGenerator generate;

  @override
  State<CaptionsSheet> createState() => _CaptionsSheetState();
}

class _CaptionsSheetState extends State<CaptionsSheet> {
  bool _busy = false;
  bool _better = false;
  String _status = '';
  double? _progress;

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _status = '';
      _progress = null;
    });
    try {
      await widget.generate(_better, (String s, double? p) {
        if (mounted) {
          setState(() {
            _status = s;
            _progress = p;
          });
        }
      });
    } catch (e) {
      if (mounted) setState(() => _status = 'Could not make captions: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _edit(ClipOverlay c) async {
    final String? t = await askText(context, initial: c.text);
    if (t == null || t.trim().isEmpty) return;
    widget.state.updateOverlay(c.copyWith(text: t.trim()));
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: widget.state,
      builder: (BuildContext context, Widget? child) {
        final List<ClipOverlay> lines = widget.state.captions;
        final double size = lines.isEmpty ? 0.045 : lines.first.sizeFrac;
        return SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              20,
              0,
              20,
              20 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Auto captions (English)',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 6),
                Text(
                  'Listens to the speech in your video and adds captions. '
                  'Works on the phone. The first time it downloads a speech '
                  'model, so connect to the internet once.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 12),
                if (_busy) ...<Widget>[
                  LinearProgressIndicator(value: _progress),
                  const SizedBox(height: 8),
                  Text(_status),
                ] else ...<Widget>[
                  Wrap(
                    spacing: 8,
                    children: <Widget>[
                      ChoiceChip(
                        label: const Text('Fast'),
                        selected: !_better,
                        onSelected: (_) => setState(() => _better = false),
                      ),
                      ChoiceChip(
                        label: const Text('Better accuracy'),
                        selected: _better,
                        onSelected: (_) => setState(() => _better = true),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: _run,
                    icon: const Icon(Icons.closed_caption_rounded),
                    label: Text(
                      lines.isEmpty ? 'Generate captions' : 'Generate again',
                    ),
                  ),
                  if (_status.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 8),
                    SelectableText(_status),
                  ],
                ],
                if (lines.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 16),
                  Text('Text size', style: theme.textTheme.titleSmall),
                  Slider(
                    min: 0.025,
                    max: 0.09,
                    value: size.clamp(0.025, 0.09).toDouble(),
                    onChanged: (double v) =>
                        widget.state.restyleCaptions(sizeFrac: v),
                  ),
                  Wrap(
                    spacing: 8,
                    children: <Widget>[
                      ActionChip(
                        label: const Text('Top'),
                        onPressed: () => widget.state.restyleCaptions(cy: 0.15),
                      ),
                      ActionChip(
                        label: const Text('Middle'),
                        onPressed: () => widget.state.restyleCaptions(cy: 0.5),
                      ),
                      ActionChip(
                        label: const Text('Bottom'),
                        onPressed: () => widget.state.restyleCaptions(cy: 0.85),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text('${lines.length} lines. Tap a line to fix a mistake.',
                      style: theme.textTheme.titleSmall),
                  SizedBox(
                    height: 220,
                    child: ListView.builder(
                      itemCount: lines.length,
                      itemBuilder: (BuildContext context, int i) {
                        final ClipOverlay c = lines[i];
                        return ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          title: Text(c.text, maxLines: 2),
                          subtitle: Text(_time(c.startMs)),
                          onTap: () => _edit(c),
                          trailing: IconButton(
                            icon: const Icon(Icons.close_rounded),
                            onPressed: () => widget.state.deleteOverlay(c.id),
                          ),
                        );
                      },
                    ),
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => widget.state.replaceCaptions(
                            const <ClipOverlay>[],
                          ),
                          child: const Text('Remove all'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Done'),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
