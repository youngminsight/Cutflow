import 'package:flutter/material.dart';

import '../logic/editor_state.dart';
import '../logic/models.dart';

const List<String> kEmojis = <String>[
  '😀', '😂', '😍', '🔥', '👍', '🎉', '❤️', '⭐', '😎', '🙌',
  '💯', '✨', '🎵', '📸', '🌍', '🌈', '🙏', '😢', '😡', '🤔',
  '🥳', '💪', '👏', '🏆', '🎬', '🍕', '⚽', '🚗', '🌟', '💥',
  '😴', '🤩', '😜', '🕺', '💃', '👑', '🎁', '🌹', '☀️', '🌙',
];

const List<int> kTextColors = <int>[
  0xFFFFFFFF,
  0xFFFFEB3B,
  0xFF22D3EE,
  0xFFFF80AB,
  0xFF69F0AE,
  0xFF000000,
];

String _time(int ms) {
  final int total = (ms / 1000).round();
  final int m = total ~/ 60;
  final int s = total % 60;
  return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
}

Future<String?> askText(BuildContext context) {
  final TextEditingController controller = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (BuildContext ctx) => AlertDialog(
      title: const Text('Add text'),
      content: TextField(
        controller: controller,
        autofocus: true,
        minLines: 1,
        maxLines: 3,
        decoration: const InputDecoration(hintText: 'Type your text'),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, controller.text),
          child: const Text('Add'),
        ),
      ],
    ),
  );
}

Future<String?> pickSticker(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    builder: (BuildContext ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: GridView.count(
          shrinkWrap: true,
          crossAxisCount: 6,
          children: <Widget>[
            for (final String e in kEmojis)
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => Navigator.pop(ctx, e),
                child: Center(
                  child: Text(e, style: const TextStyle(fontSize: 30)),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

/// Edit one text or sticker: words, colour, size and when it shows.
class OverlayEditorSheet extends StatefulWidget {
  const OverlayEditorSheet({super.key, required this.state, required this.id});

  final EditorState state;
  final String id;

  @override
  State<OverlayEditorSheet> createState() => _OverlayEditorSheetState();
}

class _OverlayEditorSheetState extends State<OverlayEditorSheet> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(
      text: widget.state.overlayById(widget.id)?.text ?? '',
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: widget.state,
      builder: (BuildContext context, Widget? child) {
        final ClipOverlay? o = widget.state.overlayById(widget.id);
        if (o == null) return const SizedBox(height: 80);
        final int total =
            widget.state.totalOutputMs < 1000 ? 1000 : widget.state.totalOutputMs;
        final bool isText = o.kind == OverlayKind.text;
        return SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              20,
              0,
              20,
              20 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  isText ? 'Edit text' : 'Edit sticker',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                if (isText) ...<Widget>[
                  TextField(
                    controller: _controller,
                    minLines: 1,
                    maxLines: 3,
                    onChanged: (String v) {
                      if (v.trim().isNotEmpty) {
                        widget.state.updateOverlay(o.copyWith(text: v));
                      }
                    },
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 10,
                    children: <Widget>[
                      for (final int c in kTextColors)
                        GestureDetector(
                          onTap: () =>
                              widget.state.updateOverlay(o.copyWith(colorValue: c)),
                          child: Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: Color(c),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: o.colorValue == c
                                    ? theme.colorScheme.primary
                                    : Colors.white24,
                                width: o.colorValue == c ? 3 : 1,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                ],
                Text('Size', style: theme.textTheme.titleSmall),
                Slider(
                  min: 0.03,
                  max: 0.25,
                  value: o.sizeFrac.clamp(0.03, 0.25).toDouble(),
                  onChanged: (double v) =>
                      widget.state.updateOverlay(o.copyWith(sizeFrac: v)),
                ),
                Text(
                  'Shows from ${_time(o.startMs)} to ${_time(o.endMs)}',
                  style: theme.textTheme.titleSmall,
                ),
                RangeSlider(
                  min: 0,
                  max: total.toDouble(),
                  values: RangeValues(
                    o.startMs.clamp(0, total).toDouble(),
                    o.endMs.clamp(0, total).toDouble(),
                  ),
                  onChanged: (RangeValues v) {
                    final int s = v.start.round();
                    final int e = v.end.round();
                    if (e - s < 300) return;
                    widget.state.updateOverlay(o.copyWith(startMs: s, endMs: e));
                  },
                ),
                Text(
                  'Drag it on the video to move it.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          widget.state.deleteOverlay(o.id);
                          Navigator.pop(context);
                        },
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('Delete'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Done'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Edit one music or voice-over track: volume and start time.
class TrackEditorSheet extends StatelessWidget {
  const TrackEditorSheet({super.key, required this.state, required this.id});

  final EditorState state;
  final String id;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        final AudioTrack? t = state.trackById(id);
        if (t == null) return const SizedBox(height: 80);
        final int total =
            state.totalOutputMs < 1000 ? 1000 : state.totalOutputMs;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  t.kind == TrackKind.music ? 'Music' : 'Voice-over',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                Text(t.label, maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 12),
                Text('Volume ${(t.volume * 100).round()}%',
                    style: theme.textTheme.titleSmall),
                Slider(
                  min: 0,
                  max: 2,
                  value: t.volume.clamp(0.0, 2.0).toDouble(),
                  onChanged: (double v) =>
                      state.updateTrack(t.copyWith(volume: v)),
                ),
                Text('Starts at ${_time(t.startMs)}',
                    style: theme.textTheme.titleSmall),
                Slider(
                  min: 0,
                  max: total.toDouble(),
                  value: t.startMs.clamp(0, total).toDouble(),
                  onChanged: (double v) =>
                      state.updateTrack(t.copyWith(startMs: v.round())),
                ),
                const SizedBox(height: 8),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          state.deleteTrack(t.id);
                          Navigator.pop(context);
                        },
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('Delete'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Done'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Volume of the original sound in the videos.
class SoundSheet extends StatelessWidget {
  const SoundSheet({super.key, required this.state});

  final EditorState state;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Original sound',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text('Volume ${(state.originalVolume * 100).round()}%'),
                Slider(
                  min: 0,
                  max: 1.5,
                  value: state.originalVolume.clamp(0.0, 1.5).toDouble(),
                  onChanged: state.setOriginalVolume,
                ),
                Wrap(
                  spacing: 8,
                  children: <Widget>[
                    ActionChip(
                      label: const Text('Mute'),
                      onPressed: () => state.setOriginalVolume(0),
                    ),
                    ActionChip(
                      label: const Text('Reset to 100%'),
                      onPressed: () => state.setOriginalVolume(1),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Music and voice-overs are mixed in when you export. '
                  'They do not play in this preview.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
