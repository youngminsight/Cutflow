import 'package:flutter/material.dart';

import '../logic/export_service.dart';
import '../logic/models.dart';

class ExportSheet extends StatefulWidget {
  const ExportSheet({
    super.key,
    required this.segments,
    required this.overlays,
    required this.tracks,
    required this.originalVolume,
    required this.canvas,
  });

  final List<Segment> segments;
  final List<ClipOverlay> overlays;
  final List<AudioTrack> tracks;
  final double originalVolume;
  final CropPreset canvas;

  @override
  State<ExportSheet> createState() => _ExportSheetState();
}

class _ExportSheetState extends State<ExportSheet> {
  int _quality = 720;
  bool _running = false;
  double _progress = 0;
  ExportResult? _result;

  Future<void> _start() async {
    setState(() {
      _running = true;
      _progress = 0;
      _result = null;
    });
    final ExportResult r = await ExportService().export(
      segments: widget.segments,
      overlays: widget.overlays,
      tracks: widget.tracks,
      originalVolume: widget.originalVolume,
      canvas: widget.canvas,
      shortSide: _quality,
      onProgress: (double p) {
        if (mounted) setState(() => _progress = p);
      },
    );
    if (mounted) {
      setState(() {
        _running = false;
        _result = r;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ExportResult? result = _result;
    final bool extras = widget.overlays.isNotEmpty ||
        widget.tracks.isNotEmpty ||
        (widget.originalVolume - 1.0).abs() > 0.001;

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          8,
          20,
          20 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Export video',
                style: theme.textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 16),
              if (_running) ...<Widget>[
                LinearProgressIndicator(value: _progress),
                const SizedBox(height: 10),
                Text('${(_progress * 100).round()}%  Keep Cutflow open while it works.'),
                const SizedBox(height: 14),
                OutlinedButton(
                  onPressed: ExportService.stop,
                  child: const Text('Stop'),
                ),
              ] else if (result != null) ...<Widget>[
                Icon(
                  result.ok ? Icons.check_circle_rounded : Icons.error_rounded,
                  color: result.ok ? Colors.greenAccent : Colors.redAccent,
                  size: 40,
                ),
                const SizedBox(height: 10),
                SelectableText(result.message),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Close'),
                ),
              ] else ...<Widget>[
                Text('Shape: ${widget.canvas.label}',
                    style: theme.textTheme.titleSmall),
                const SizedBox(height: 4),
                Text(
                  'Change the shape with Canvas in the toolbar.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 16),
                Text('Quality', style: theme.textTheme.titleSmall),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: <Widget>[
                    for (final int q in const <int>[480, 720, 1080])
                      ChoiceChip(
                        label: Text('${q}p'),
                        selected: _quality == q,
                        onSelected: (_) => setState(() => _quality = q),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  extras
                      ? 'Text, stickers and sound need a second pass, so this takes longer. 720p is a good start.'
                      : 'Higher quality takes longer on this phone. 720p is a good start.',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 18),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: _start,
                        child: const Text('Start export'),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
