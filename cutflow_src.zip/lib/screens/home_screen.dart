import 'package:flutter/material.dart';

import 'editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: <Widget>[
              const Spacer(),
              Container(
                width: 92,
                height: 92,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[Color(0xFF22D3EE), Color(0xFF6366F1)],
                  ),
                ),
                child: const Icon(Icons.content_cut_rounded,
                    size: 44, color: Colors.white),
              ),
              const SizedBox(height: 24),
              Text(
                'CUTFLOW',
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: 5,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Simple video editing on your phone',
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 36),
              FilledButton.icon(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const EditorScreen(),
                    ),
                  );
                },
                icon: const Icon(Icons.add_rounded),
                label: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  child: Text('New project'),
                ),
              ),
              const Spacer(),
              Text(
                'Version 0.1 (Drop 1). Uses FFmpeg (GPL-3.0). '
                'The app source code is public.',
                textAlign: TextAlign.center,
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
