import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:video_player/video_player.dart';

import '../logic/editor_state.dart';
import '../logic/export_service.dart';
import '../logic/models.dart';
import 'export_sheet.dart';
import 'overlay_sheets.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final EditorState state = EditorState();
  VideoPlayerController? _vc;
  String? _loadedPath;
  int _token = 0;
  bool _busy = false;
  bool _advancing = false;
  AudioRecorder? _rec;
  int _voiceStartMs = 0;

  @override
  void dispose() {
    _vc?.removeListener(_onTick);
    _vc?.dispose();
    _rec?.dispose();
    state.dispose();
    super.dispose();
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  // ---------- player ----------

  Future<void> _disposePlayer() async {
    final VideoPlayerController? old = _vc;
    _vc = null;
    _loadedPath = null;
    if (old != null) {
      old.removeListener(_onTick);
      await old.dispose();
    }
  }

  Future<void> _syncPlayer({bool autoplay = false}) async {
    final int my = ++_token;
    final Segment? seg = state.current;
    if (seg == null) {
      await _disposePlayer();
      if (mounted) setState(() {});
      return;
    }
    if (_loadedPath != seg.path) {
      await _disposePlayer();
      final VideoPlayerController fresh =
          VideoPlayerController.file(File(seg.path));
      try {
        await fresh.initialize();
      } catch (e) {
        await fresh.dispose();
        _toast('This video could not be opened.');
        return;
      }
      if (my != _token || !mounted) {
        await fresh.dispose();
        return;
      }
      fresh.addListener(_onTick);
      _vc = fresh;
      _loadedPath = seg.path;
    }
    final VideoPlayerController c = _vc!;
    await c.setPlaybackSpeed(seg.speed);
    await c.seekTo(Duration(milliseconds: seg.startMs));
    if (autoplay) await c.play();
    if (mounted) setState(() {});
  }

  void _onTick() {
    final VideoPlayerController? c = _vc;
    final Segment? seg = state.current;
    if (c == null || seg == null || !c.value.isInitialized) return;
    final int pos = c.value.position.inMilliseconds;
    final bool finished = c.value.isPlaying || c.value.isCompleted;
    if (finished && pos >= seg.endMs - 30 && !_advancing) {
      _advancing = true;
      c.pause();
      final int next = state.selected + 1;
      if (next < state.segments.length) {
        state.select(next);
        _syncPlayer(autoplay: true).whenComplete(() => _advancing = false);
      } else {
        c
            .seekTo(Duration(milliseconds: seg.startMs))
            .whenComplete(() => _advancing = false);
      }
    }
  }

  int _globalNow() {
    final VideoPlayerController? c = _vc;
    if (c == null) return 0;
    return state.globalMsFor(state.selected, c.value.position.inMilliseconds);
  }

  // ---------- clip actions ----------

  Future<void> _addClip() async {
    if (_busy) return;
    final XFile? picked =
        await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked == null) return;
    setState(() => _busy = true);
    try {
      final VideoPlayerController probe =
          VideoPlayerController.file(File(picked.path));
      await probe.initialize();
      final int ms = probe.value.duration.inMilliseconds;
      await probe.dispose();
      if (ms < 500) {
        _toast('That video is too short.');
        return;
      }
      final bool audio = await MediaProbe.hasAudio(picked.path);
      state.add(Segment(
        path: picked.path,
        sourceMs: ms,
        hasAudio: audio,
        startMs: 0,
        endMs: ms,
      ));
      await _syncPlayer();
    } catch (e) {
      _toast('Could not add that video: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _split() {
    final VideoPlayerController? c = _vc;
    if (c == null) return;
    final int pos = c.value.position.inMilliseconds;
    if (!state.splitAt(pos)) {
      _toast('Move the playhead into the clip first, away from the ends.');
      return;
    }
    _syncPlayer();
  }

  void _delete() {
    state.deleteCurrent();
    _syncPlayer();
  }

  void _rotate() {
    final Segment? seg = state.current;
    if (seg == null) return;
    state.updateCurrent(seg.copyWith(rotation: (seg.rotation + 90) % 360));
  }

  Future<T?> _chooseChip<T>({
    required List<T> values,
    required String Function(T) label,
    required T selected,
  }) {
    return showModalBottomSheet<T>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (final T v in values)
                ChoiceChip(
                  label: Text(label(v)),
                  selected: v == selected,
                  onSelected: (_) => Navigator.pop(ctx, v),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickSpeed() async {
    final Segment? seg = state.current;
    if (seg == null) return;
    final double? v = await _chooseChip<double>(
      values: kSpeeds,
      label: (double s) => '${s}x',
      selected: seg.speed,
    );
    if (v != null) {
      state.updateCurrent(seg.copyWith(speed: v));
      await _vc?.setPlaybackSpeed(v);
    }
  }

  Future<void> _pickCrop() async {
    final Segment? seg = state.current;
    if (seg == null) return;
    final CropPreset? v = await _chooseChip<CropPreset>(
      values: CropPreset.values,
      label: (CropPreset p) => p.label,
      selected: seg.crop,
    );
    if (v != null) state.updateCurrent(seg.copyWith(crop: v));
  }

  Future<void> _pickFilter() async {
    final Segment? seg = state.current;
    if (seg == null) return;
    final FilterPreset? v = await _chooseChip<FilterPreset>(
      values: FilterPreset.values,
      label: (FilterPreset f) => f.label,
      selected: seg.filter,
    );
    if (v != null) state.updateCurrent(seg.copyWith(filter: v));
  }

  Future<void> _pickCanvas() async {
    final CropPreset? v = await _chooseChip<CropPreset>(
      values: <CropPreset>[
        for (final CropPreset p in CropPreset.values)
          if (p != CropPreset.original) p,
      ],
      label: (CropPreset p) => p.label,
      selected: state.canvas,
    );
    if (v != null) state.setCanvas(v);
  }

  // ---------- text, stickers, sound ----------

  void _addOverlay(OverlayKind kind, String text) {
    final int total = state.totalOutputMs;
    final int g = _globalNow();
    final int start = g.clamp(0, math.max(0, total - 500)).toInt();
    final int end = math.min(total, start + 3000);
    final ClipOverlay o = ClipOverlay(
      id: state.newId(),
      kind: kind,
      text: text,
      startMs: start,
      endMs: end,
      cy: kind == OverlayKind.text ? 0.75 : 0.5,
      sizeFrac: kind == OverlayKind.text ? 0.06 : 0.14,
    );
    state.addOverlay(o);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (BuildContext ctx) =>
          OverlayEditorSheet(state: state, id: o.id),
    );
  }

  Future<void> _addText() async {
    final String? t = await askText(context);
    if (t == null || t.trim().isEmpty) return;
    _addOverlay(OverlayKind.text, t.trim());
  }

  Future<void> _addSticker() async {
    final String? e = await pickSticker(context);
    if (e == null) return;
    _addOverlay(OverlayKind.sticker, e);
  }

  Future<void> _addMusic() async {
    try {
      final List<PlatformFile> files =
          await FilePicker.pickFiles(type: FileType.audio);
      if (files.isEmpty) return;
      final String? path = files.first.path;
      if (path == null) {
        _toast('Could not read that audio file.');
        return;
      }
      state.addTrack(AudioTrack(
        id: state.newId(),
        kind: TrackKind.music,
        path: path,
        label: files.first.name,
        startMs: 0,
      ));
      _toast('Music added. It is mixed in when you export, not in this preview.');
    } catch (e) {
      _toast('Could not add music: $e');
    }
  }

  Future<void> _recordVoice() async {
    final VideoPlayerController? c = _vc;
    if (c == null) return;
    await c.pause();
    if (!mounted) return;
    bool recording = false;
    String? error;
    await showModalBottomSheet<void>(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext ctx) => StatefulBuilder(
        builder: (BuildContext ctx, StateSetter setSheet) {
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Voice-over',
                    style: Theme.of(ctx)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    recording
                        ? 'Recording. The video is playing. Tap Stop when you are done.'
                        : 'Tap Start. The video plays from where it is now while your voice is recorded. Use headphones to avoid echo.',
                  ),
                  if (error != null) ...<Widget>[
                    const SizedBox(height: 8),
                    Text(error!, style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 16),
                  Row(
                    children: <Widget>[
                      if (!recording)
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: const Text('Cancel'),
                          ),
                        ),
                      if (!recording) const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton.icon(
                          icon: Icon(recording
                              ? Icons.stop_rounded
                              : Icons.mic_rounded),
                          label: Text(recording ? 'Stop' : 'Start'),
                          onPressed: () async {
                            if (!recording) {
                              try {
                                final AudioRecorder rec = AudioRecorder();
                                _rec = rec;
                                if (!await rec.hasPermission()) {
                                  setSheet(() => error =
                                      'Microphone permission was not given.');
                                  return;
                                }
                                final Directory dir =
                                    await getTemporaryDirectory();
                                final String path =
                                    '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
                                _voiceStartMs = _globalNow();
                                await rec.start(
                                  const RecordConfig(
                                      encoder: AudioEncoder.aacLc),
                                  path: path,
                                );
                                await c.play();
                                setSheet(() => recording = true);
                              } catch (e) {
                                setSheet(() =>
                                    error = 'Could not start recording: $e');
                              }
                            } else {
                              await c.pause();
                              final String? out = await _rec?.stop();
                              await _rec?.dispose();
                              _rec = null;
                              if (out != null) {
                                state.addTrack(AudioTrack(
                                  id: state.newId(),
                                  kind: TrackKind.voice,
                                  path: out,
                                  label: 'Voice-over',
                                  startMs: _voiceStartMs,
                                ));
                              }
                              if (ctx.mounted) Navigator.pop(ctx);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _openExport() async {
    await _vc?.pause();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext ctx) => ExportSheet(
        segments: List<Segment>.of(state.segments),
        overlays: List<ClipOverlay>.of(state.overlays),
        tracks: List<AudioTrack>.of(state.tracks),
        originalVolume: state.originalVolume,
        canvas: state.canvas,
      ),
    );
  }

  // ---------- screens ----------

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        final Segment? seg = state.current;
        return Scaffold(
          appBar: AppBar(
            title: const Text('New project'),
            actions: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: FilledButton(
                  onPressed:
                      (state.segments.isEmpty || _busy) ? null : _openExport,
                  child: const Text('Export'),
                ),
              ),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: <Widget>[
                if (_busy) const LinearProgressIndicator(),
                Expanded(
                  child: seg == null ? _emptyState() : _editor(seg),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _emptyState() {
    final ThemeData theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.video_library_rounded,
                size: 56, color: theme.colorScheme.primary),
            const SizedBox(height: 16),
            Text(
              'Add your first video',
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              'Pick a video from your gallery to start editing.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _busy ? null : _addClip,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Add video'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _clipWidget(Segment seg, VideoPlayerController c) {
    final Size size = c.value.size;
    Widget video = RotatedBox(
      quarterTurns: seg.rotation ~/ 90,
      child: SizedBox(
        width: size.width,
        height: size.height,
        child: VideoPlayer(c),
      ),
    );
    final double? ratio = seg.crop.ratio;
    if (ratio != null) {
      video = SizedBox(
        width: 1000 * ratio,
        height: 1000,
        child: ClipRect(child: FittedBox(fit: BoxFit.cover, child: video)),
      );
    }
    final List<double>? matrix = seg.filter.previewMatrix;
    if (matrix != null) {
      video = ColorFiltered(
        colorFilter: ColorFilter.matrix(matrix),
        child: video,
      );
    }
    return video;
  }

  Widget _outlinedText(String text, double size, Color color) {
    return Stack(
      children: <Widget>[
        Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w800,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = size * 0.12
              ..color = Colors.black,
          ),
        ),
        Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w800,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _overlayWidget(ClipOverlay o, double bw, double bh) {
    final bool selected = o.id == state.selectedOverlayId;
    final double fontSize = o.sizeFrac * bh;
    Widget content = o.kind == OverlayKind.sticker
        ? Text(o.text, style: TextStyle(fontSize: fontSize))
        : _outlinedText(o.text, fontSize, Color(o.colorValue));
    content = ConstrainedBox(
      constraints: BoxConstraints(maxWidth: bw * 0.9),
      child: content,
    );
    if (selected) {
      content = DecoratedBox(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.cyanAccent, width: 1.5),
        ),
        child: content,
      );
    }
    return Positioned(
      left: o.cx * bw,
      top: o.cy * bh,
      child: FractionalTranslation(
        translation: const Offset(-0.5, -0.5),
        child: GestureDetector(
          onTap: () => state.selectOverlay(o.id),
          onPanStart: (DragStartDetails d) => state.selectOverlay(o.id),
          onPanUpdate: (DragUpdateDetails d) {
            state.updateOverlay(o.copyWith(
              cx: (o.cx + d.delta.dx / bw).clamp(0.0, 1.0).toDouble(),
              cy: (o.cy + d.delta.dy / bh).clamp(0.0, 1.0).toDouble(),
            ));
          },
          child: content,
        ),
      ),
    );
  }

  Widget _preview(Segment seg) {
    final VideoPlayerController? c = _vc;
    if (c == null || !c.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }
    final double ratio = state.canvas.ratio ?? (16 / 9);
    return Center(
      child: AspectRatio(
        aspectRatio: ratio,
        child: ValueListenableBuilder<VideoPlayerValue>(
          valueListenable: c,
          builder: (BuildContext context, VideoPlayerValue v, Widget? w) {
            final int g = state.globalMsFor(
              state.selected,
              v.position.inMilliseconds,
            );
            return LayoutBuilder(
              builder: (BuildContext context, BoxConstraints box) {
                final double bw = box.maxWidth;
                final double bh = box.maxHeight;
                return ClipRect(
                  child: Stack(
                    children: <Widget>[
                      const Positioned.fill(
                        child: ColoredBox(color: Colors.black),
                      ),
                      Positioned.fill(
                        child: FittedBox(
                          fit: BoxFit.contain,
                          child: _clipWidget(seg, c),
                        ),
                      ),
                      Positioned.fill(
                        child: GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: () => state.selectOverlay(null),
                        ),
                      ),
                      for (final ClipOverlay o in state.overlays)
                        if (o.id == state.selectedOverlayId ||
                            (g >= o.startMs && g <= o.endMs))
                          _overlayWidget(o, bw, bh),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _editor(Segment seg) {
    final ThemeData theme = Theme.of(context);
    final VideoPlayerController? c = _vc;
    return Column(
      children: <Widget>[
        Expanded(child: _preview(seg)),
        if (c != null && c.value.isInitialized)
          ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: c,
            builder: (BuildContext context, VideoPlayerValue v, Widget? w) {
              final int pos = (v.position.inMilliseconds - seg.startMs)
                  .clamp(0, seg.trimmedMs)
                  .toInt();
              return Row(
                children: <Widget>[
                  IconButton(
                    iconSize: 40,
                    icon: Icon(v.isPlaying
                        ? Icons.pause_circle_filled_rounded
                        : Icons.play_circle_filled_rounded),
                    onPressed: () {
                      if (v.isPlaying) {
                        c.pause();
                      } else {
                        final int p = v.position.inMilliseconds;
                        if (p >= seg.endMs - 50 || p < seg.startMs) {
                          c.seekTo(Duration(milliseconds: seg.startMs));
                        }
                        c.play();
                      }
                    },
                  ),
                  Text('${formatMs(pos)} / ${formatMs(seg.trimmedMs)}'),
                  Expanded(
                    child: Slider(
                      value: pos.toDouble(),
                      min: 0,
                      max: seg.trimmedMs.toDouble(),
                      onChanged: (double x) => c.seekTo(
                        Duration(milliseconds: seg.startMs + x.round()),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text('Trim: start ${formatMs(seg.startMs)}',
                  style: theme.textTheme.bodySmall),
              Text('end ${formatMs(seg.endMs)}',
                  style: theme.textTheme.bodySmall),
            ],
          ),
        ),
        RangeSlider(
          min: 0,
          max: seg.sourceMs.toDouble(),
          values: RangeValues(seg.startMs.toDouble(), seg.endMs.toDouble()),
          onChanged: (RangeValues v) {
            final int s = v.start.round();
            final int e = v.end.round();
            if (e - s < 500) return;
            state.updateCurrent(seg.copyWith(startMs: s, endMs: e));
          },
          onChangeEnd: (RangeValues v) {
            _vc?.seekTo(Duration(milliseconds: v.start.round()));
          },
        ),
        _timeline(),
        _layers(),
        const SizedBox(height: 6),
        _toolbar(seg),
        const SizedBox(height: 6),
      ],
    );
  }

  Widget _timeline() {
    final ColorScheme cs = Theme.of(context).colorScheme;
    return SizedBox(
      height: 62,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: state.segments.length,
        separatorBuilder: (BuildContext context, int index) =>
            const SizedBox(width: 6),
        itemBuilder: (BuildContext context, int i) {
          final Segment s = state.segments[i];
          final bool sel = i == state.selected;
          final double w =
              (s.outputMs / 1000 * 14).clamp(84.0, 220.0).toDouble();
          return GestureDetector(
            onTap: () {
              state.select(i);
              _syncPlayer();
            },
            child: Container(
              width: w,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: sel
                    ? cs.primary.withOpacity(0.25)
                    : const Color(0xFF1C1C1E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: sel ? cs.primary : Colors.white12,
                  width: sel ? 2 : 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text('Clip ${i + 1}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(
                    s.speed == 1.0
                        ? formatMs(s.outputMs)
                        : '${formatMs(s.outputMs)}  ${s.speed}x',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  /// Chips for every text, sticker, music and voice-over. Tap one to edit it.
  Widget _layers() {
    if (state.overlays.isEmpty && state.tracks.isEmpty) {
      return const SizedBox.shrink();
    }
    final List<Widget> chips = <Widget>[
      for (final ClipOverlay o in state.overlays)
        ActionChip(
          avatar: Icon(
            o.kind == OverlayKind.text
                ? Icons.title_rounded
                : Icons.emoji_emotions_rounded,
            size: 18,
          ),
          label: Text(
            o.text.length > 12 ? '${o.text.substring(0, 12)}...' : o.text,
          ),
          onPressed: () {
            state.selectOverlay(o.id);
            showModalBottomSheet<void>(
              context: context,
              isScrollControlled: true,
              showDragHandle: true,
              builder: (BuildContext ctx) =>
                  OverlayEditorSheet(state: state, id: o.id),
            );
          },
        ),
      for (final AudioTrack t in state.tracks)
        ActionChip(
          avatar: Icon(
            t.kind == TrackKind.music
                ? Icons.music_note_rounded
                : Icons.mic_rounded,
            size: 18,
          ),
          label: Text(
            t.label.length > 14 ? '${t.label.substring(0, 14)}...' : t.label,
          ),
          onPressed: () {
            showModalBottomSheet<void>(
              context: context,
              showDragHandle: true,
              builder: (BuildContext ctx) =>
                  TrackEditorSheet(state: state, id: t.id),
            );
          },
        ),
    ];
    return SizedBox(
      height: 46,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        itemCount: chips.length,
        separatorBuilder: (BuildContext context, int index) =>
            const SizedBox(width: 8),
        itemBuilder: (BuildContext context, int i) => chips[i],
      ),
    );
  }

  Widget _toolbar(Segment seg) {
    return SizedBox(
      height: 64,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: <Widget>[
          _Tool(Icons.add_rounded, 'Add', _busy ? null : _addClip),
          _Tool(Icons.call_split_rounded, 'Split', _split),
          _Tool(Icons.delete_outline_rounded, 'Delete', _delete),
          _Tool(Icons.arrow_back_rounded, 'Move left',
              () => state.moveCurrent(-1)),
          _Tool(Icons.arrow_forward_rounded, 'Move right',
              () => state.moveCurrent(1)),
          _Tool(Icons.speed_rounded, '${seg.speed}x', _pickSpeed),
          _Tool(Icons.rotate_90_degrees_cw_rounded, 'Rotate', _rotate),
          _Tool(Icons.crop_rounded, 'Crop', _pickCrop),
          _Tool(Icons.filter_vintage_rounded, 'Filter', _pickFilter),
          _Tool(Icons.title_rounded, 'Text', _addText),
          _Tool(Icons.emoji_emotions_rounded, 'Sticker', _addSticker),
          _Tool(Icons.music_note_rounded, 'Music', _addMusic),
          _Tool(Icons.mic_rounded, 'Voice', _recordVoice),
          _Tool(Icons.volume_up_rounded, 'Sound', () {
            showModalBottomSheet<void>(
              context: context,
              showDragHandle: true,
              builder: (BuildContext ctx) => SoundSheet(state: state),
            );
          }),
          _Tool(Icons.aspect_ratio_rounded, 'Canvas', _pickCanvas),
        ],
      ),
    );
  }
}

class _Tool extends StatelessWidget {
  const _Tool(this.icon, this.label, this.onTap);

  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: SizedBox(
        width: 76,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: onTap == null ? Colors.white24 : null),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
