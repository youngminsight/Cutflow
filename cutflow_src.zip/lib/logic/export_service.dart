import 'dart:async';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new_min_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min_gpl/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min_gpl/return_code.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';

import 'export_commands.dart';
import 'models.dart';

class ExportResult {
  const ExportResult({required this.ok, this.message = '', this.path});

  final bool ok;
  final String message;
  final String? path;
}

class MediaProbe {
  MediaProbe._();

  /// True if the video has a sound track. If we cannot tell, assume it does.
  static Future<bool> hasAudio(String path) async {
    try {
      final dynamic session = await FFprobeKit.getMediaInformation(path);
      final dynamic info = await session.getMediaInformation();
      if (info == null) return true;
      final dynamic streams = await info.getStreams();
      if (streams == null) return true;
      for (final dynamic s in streams) {
        final dynamic type = await s.getType();
        if (type == 'audio') return true;
      }
      return false;
    } catch (_) {
      return true;
    }
  }
}

class ExportService {
  final List<String> _logs = <String>[];

  String _failText(String head) {
    final int from = _logs.length > 12 ? _logs.length - 12 : 0;
    return '$head\n\nLast messages from the video engine:\n'
        '${_logs.skip(from).join('\n')}';
  }

  Future<bool> _run(String command, {void Function(int ms)? onTime}) async {
    final Completer<bool> done = Completer<bool>();
    await FFmpegKit.executeAsync(
      command,
      (dynamic session) async {
        final dynamic code = await session.getReturnCode();
        if (!done.isCompleted) done.complete(ReturnCode.isSuccess(code));
      },
      (dynamic log) {
        final dynamic m = log.getMessage();
        if (m is String && m.trim().isNotEmpty) {
          _logs.add(m.trim());
          if (_logs.length > 40) _logs.removeAt(0);
        }
      },
      (dynamic stats) {
        if (onTime != null) {
          final dynamic t = stats.getTime();
          if (t is num && t >= 0) onTime(t.toInt());
        }
      },
    );
    return done.future;
  }

  Future<ExportResult> export({
    required List<Segment> segments,
    required CropPreset canvas,
    required int shortSide,
    required void Function(double progress) onProgress,
  }) async {
    _logs.clear();
    Directory? work;
    try {
      final Directory tmp = await getTemporaryDirectory();
      final String stamp = DateTime.now().millisecondsSinceEpoch.toString();
      work = await Directory('${tmp.path}/cutflow_$stamp').create(recursive: true);
      final List<int> size = ExportCommands.canvasSize(canvas, shortSide);
      final int totalMs =
          segments.fold<int>(0, (int a, Segment s) => a + s.outputMs);
      final List<String> parts = <String>[];
      int doneMs = 0;

      for (int i = 0; i < segments.length; i++) {
        final Segment s = segments[i];
        final String out = '${work.path}/part_$i.mp4';
        final int base = doneMs;
        final bool ok = await _run(
          ExportCommands.segmentCommand(
            s: s,
            outPath: out,
            width: size[0],
            height: size[1],
          ),
          onTime: (int ms) {
            final int inPart = ms > s.outputMs ? s.outputMs : ms;
            final double p = (base + inPart) / totalMs;
            onProgress((p * 0.95).clamp(0.0, 0.95).toDouble());
          },
        );
        if (!ok) {
          return ExportResult(
            ok: false,
            message: _failText('Clip ${i + 1} could not be processed.'),
          );
        }
        parts.add(out);
        doneMs += s.outputMs;
      }

      final String finalPath = '${tmp.path}/Cutflow_$stamp.mp4';
      if (parts.length == 1) {
        await File(parts.first).copy(finalPath);
      } else {
        final File list = File('${work.path}/list.txt');
        await list.writeAsString(ExportCommands.concatList(parts));
        final bool ok = await _run(
          '-y -f concat -safe 0 -i "${list.path}" -c copy '
          '-movflags +faststart "$finalPath"',
        );
        if (!ok) {
          return ExportResult(
            ok: false,
            message: _failText('The clips could not be joined.'),
          );
        }
      }
      onProgress(0.97);

      try {
        if (!await Gal.hasAccess()) {
          await Gal.requestAccess();
        }
        await Gal.putVideo(finalPath, album: 'Cutflow');
      } catch (e) {
        return ExportResult(
          ok: false,
          path: finalPath,
          message: 'The video was made but could not be saved to your gallery: $e',
        );
      }
      onProgress(1.0);
      return ExportResult(
        ok: true,
        path: finalPath,
        message: 'Saved to your gallery, in the Cutflow album.',
      );
    } catch (e) {
      return ExportResult(ok: false, message: _failText('Export failed: $e'));
    } finally {
      try {
        await work?.delete(recursive: true);
      } catch (_) {}
    }
  }

  static void stop() {
    FFmpegKit.cancel();
  }
}
