import 'dart:async';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new_min_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min_gpl/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min_gpl/return_code.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';

import 'export_commands.dart';
import 'models.dart';
import 'overlay_renderer.dart';

class ExportResult {
  const ExportResult({required this.ok, this.message = '', this.path});

  final bool ok;
  final String message;
  final String? path;
}

class MediaProbe {
  MediaProbe._();

  /// True if the video has a sound track. If we cannot tell, assume it does.
  static Future<bool> hasAudio(String path) async {
    try {
      final dynamic session = await FFprobeKit.getMediaInformation(path);
      final dynamic info = await session.getMediaInformation();
      if (info == null) return true;
      final dynamic streams = await info.getStreams();
      if (streams == null) return true;
      for (final dynamic s in streams) {
        final dynamic type = await s.getType();
        if (type == 'audio') return true;
      }
      return false;
    } catch (_) {
      return true;
    }
  }
}

class ExportService {
  final List<String> _logs = <String>[];

  String _failText(String head) {
    final int from = _logs.length > 12 ? _logs.length - 12 : 0;
    return '$head\n\nLast messages from the video engine:\n'
        '${_logs.skip(from).join('\n')}';
  }

  Future<bool> _run(String command, {void Function(int ms)? onTime}) async {
    final Completer<bool> done = Completer<bool>();
    await FFmpegKit.executeAsync(
      command,
      (dynamic session) async {
        final dynamic code = await session.getReturnCode();
        if (!done.isCompleted) done.complete(ReturnCode.isSuccess(code));
      },
      (dynamic log) {
        final dynamic m = log.getMessage();
        if (m is String && m.trim().isNotEmpty) {
          _logs.add(m.trim());
          if (_logs.length > 40) _logs.removeAt(0);
        }
      },
      (dynamic stats) {
        if (onTime != null) {
          final dynamic t = stats.getTime();
          if (t is num && t >= 0) onTime(t.toInt());
        }
      },
    );
    return done.future;
  }

  Future<ExportResult> export({
    required List<Segment> segments,
    required List<ClipOverlay> overlays,
    required List<AudioTrack> tracks,
    required double originalVolume,
    required CropPreset canvas,
    required int shortSide,
    required void Function(double progress) onProgress,
  }) async {
    _logs.clear();
    Directory? work;
    try {
      final Directory tmp = await getTemporaryDirectory();
      final String stamp = DateTime.now().millisecondsSinceEpoch.toString();
      work = await Directory('${tmp.path}/cutflow_$stamp').create(recursive: true);
      final List<int> size = ExportCommands.canvasSize(canvas, shortSide);
      final int totalMs =
          segments.fold<int>(0, (int a, Segment s) => a + s.outputMs);
      final bool needsPass2 = overlays.isNotEmpty ||
          tracks.isNotEmpty ||
          (originalVolume - 1.0).abs() > 0.001;
      final double stage1Share = needsPass2 ? 0.55 : 0.95;
      final String finalPath = '${tmp.path}/Cutflow_$stamp.mp4';
      final String stage1 = needsPass2 ? '${work.path}/stage1.mp4' : finalPath;

      // ----- pass 1: render each clip, then join them -----
      final List<String> parts = <String>[];
      int doneMs = 0;
      for (int i = 0; i < segments.length; i++) {
        final Segment s = segments[i];
        final String out = '${work.path}/part_$i.mp4';
        final int base = doneMs;
        final bool ok = await _run(
          ExportCommands.segmentCommand(
            s: s,
            outPath: out,
            width: size[0],
            height: size[1],
          ),
          onTime: (int ms) {
            final int inPart = ms > s.outputMs ? s.outputMs : ms;
            final double p = (base + inPart) / totalMs;
            onProgress((p * stage1Share).clamp(0.0, stage1Share).toDouble());
          },
        );
        if (!ok) {
          return ExportResult(
            ok: false,
            message: _failText('Clip ${i + 1} could not be processed.'),
          );
        }
        parts.add(out);
        doneMs += s.outputMs;
      }

      if (parts.length == 1) {
        await File(parts.first).copy(stage1);
      } else {
        final File list = File('${work.path}/list.txt');
        await list.writeAsString(ExportCommands.concatList(parts));
        final bool ok = await _run(
          '-y -f concat -safe 0 -i "${list.path}" -c copy '
          '-movflags +faststart "$stage1"',
        );
        if (!ok) {
          return ExportResult(
            ok: false,
            message: _failText('The clips could not be joined.'),
          );
        }
      }
      onProgress(stage1Share);

      // ----- pass 2: text, stickers and sound -----
      if (needsPass2) {
        final List<OverlayInput> pictures = <OverlayInput>[];
        for (int i = 0; i < overlays.length; i++) {
          final ClipOverlay o = overlays[i];
          if (o.startMs >= totalMs) continue;
          final RenderedOverlay r = await OverlayRenderer.render(
            overlay: o,
            canvasW: size[0],
            canvasH: size[1],
            outPath: '${work.path}/overlay_$i.png',
          );
          pictures.add(OverlayInput(
            path: r.path,
            x: (o.cx * size[0] - r.width / 2).round(),
            y: (o.cy * size[1] - r.height / 2).round(),
            startMs: o.startMs,
            endMs: o.endMs > totalMs ? totalMs : o.endMs,
          ));
        }
        final List<TrackInput> sounds = <TrackInput>[
          for (final AudioTrack t in tracks)
            if (t.startMs < totalMs)
              TrackInput(path: t.path, delayMs: t.startMs, volume: t.volume),
        ];
        onProgress(stage1Share + 0.03);
        final bool ok = await _run(
          ExportCommands.finalPassCommand(
            inPath: stage1,
            outPath: finalPath,
            overlays: pictures,
            tracks: sounds,
            originalVolume: originalVolume,
          ),
          onTime: (int ms) {
            final double p = stage1Share + 0.03 + 0.37 * (ms / totalMs);
            onProgress(p.clamp(0.0, 0.96).toDouble());
          },
        );
        if (!ok) {
          return ExportResult(
            ok: false,
            message: _failText('Text, stickers or sound could not be added.'),
          );
        }
      }
      onProgress(0.97);

      try {
        await Gal.putVideo(finalPath, album: 'Cutflow');
      } catch (e) {
        return ExportResult(
          ok: false,
          path: finalPath,
          message: 'The video was made but could not be saved to your gallery: $e',
        );
      }
      onProgress(1.0);
      return ExportResult(
        ok: true,
        path: finalPath,
        message: 'Saved to your gallery, in the Cutflow album.',
      );
    } catch (e) {
      return ExportResult(ok: false, message: _failText('Export failed: $e'));
    } finally {
      try {
        await work?.delete(recursive: true);
      } catch (_) {}
    }
  }

  static void stop() {
    FFmpegKit.cancel();
  }
}
