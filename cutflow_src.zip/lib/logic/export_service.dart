import 'dart:async';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new_min/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min/return_code.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';

import 'export_commands.dart';
import 'models.dart';
import 'overlay_renderer.dart';

class ExportResult {
  const ExportResult({
    required this.ok,
    this.message = '',
    this.path,
    this.retryable = false,
  });

  final bool ok;
  final String message;
  final String? path;

  /// True if the video engine failed, so another encoder may work.
  final bool retryable;
}

class MediaProbe {
  MediaProbe._();

  /// True if the video has a sound track. If we cannot tell, assume it does.
  static Future<bool> hasAudio(String path) async {
    try {
      final dynamic session = await FFprobeKit.getMediaInformation(path);
      final dynamic info = await session.getMediaInformation();
      if (info == null) return true;
      final dynamic streams = await info.getStreams();
      if (streams == null) return true;
      for (final dynamic s in streams) {
        final dynamic type = await s.getType();
        if (type == 'audio') return true;
      }
      return false;
    } catch (_) {
      return true;
    }
  }
}

/// Runs FFmpeg commands and remembers the last messages for error reports.
class FfmpegRunner {
  final List<String> logs = <String>[];

  String failText(String head) {
    final int from = logs.length > 12 ? logs.length - 12 : 0;
    return '$head\n\nLast messages from the video engine:\n'
        '${logs.skip(from).join('\n')}';
  }

  Future<bool> run(String command, {void Function(int ms)? onTime}) async {
    final Completer<bool> done = Completer<bool>();
    await FFmpegKit.executeAsync(
      command,
      (dynamic session) async {
        final dynamic code = await session.getReturnCode();
        if (!done.isCompleted) done.complete(ReturnCode.isSuccess(code));
      },
      (dynamic log) {
        final dynamic m = log.getMessage();
        if (m is String && m.trim().isNotEmpty) {
          logs.add(m.trim());
          if (logs.length > 40) logs.removeAt(0);
        }
      },
      (dynamic stats) {
        if (onTime != null) {
          final dynamic t = stats.getTime();
          if (t is num && t >= 0) onTime(t.toInt());
        }
      },
    );
    return done.future;
  }
}

class ExportService {
  final FfmpegRunner _ff = FfmpegRunner();

  /// Exports with the phone's video chip first; if that fails, tries again
  /// with a slower software encoder that works on every phone.
  Future<ExportResult> export({
    required List<Segment> segments,
    required List<PipLayer> layers,
    required List<ClipOverlay> overlays,
    required List<AudioTrack> tracks,
    required double originalVolume,
    required CropPreset canvas,
    required int shortSide,
    required void Function(double progress) onProgress,
  }) async {
    ExportResult r = await _exportOnce(
      hardware: true,
      segments: segments,
      layers: layers,
      overlays: overlays,
      tracks: tracks,
      originalVolume: originalVolume,
      canvas: canvas,
      shortSide: shortSide,
      onProgress: onProgress,
    );
    if (!r.ok && r.retryable) {
      onProgress(0);
      r = await _exportOnce(
        hardware: false,
        segments: segments,
        layers: layers,
        overlays: overlays,
        tracks: tracks,
        originalVolume: originalVolume,
        canvas: canvas,
        shortSide: shortSide,
        onProgress: onProgress,
      );
    }
    return r;
  }

  Future<ExportResult> _exportOnce({
    required bool hardware,
    required List<Segment> segments,
    required List<PipLayer> layers,
    required List<ClipOverlay> overlays,
    required List<AudioTrack> tracks,
    required double originalVolume,
    required CropPreset canvas,
    required int shortSide,
    required void Function(double progress) onProgress,
  }) async {
    _ff.logs.clear();
    Directory? work;
    final String encoder =
        ExportCommands.videoEncoder(hardware: hardware, shortSide: shortSide);
    ExportResult fail(String head) => ExportResult(
          ok: false,
          retryable: hardware,
          message: _ff.failText(head),
        );
    try {
      final Directory tmp = await getTemporaryDirectory();
      final String stamp = DateTime.now().millisecondsSinceEpoch.toString();
      work = await Directory('${tmp.path}/cutflow_$stamp').create(recursive: true);
      final List<int> size = ExportCommands.canvasSize(canvas, shortSide);

      int totalMs = segments.fold<int>(0, (int a, Segment s) => a + s.outputMs);
      for (int i = 1; i < segments.length; i++) {
        if (segments[i].transition != TransitionKind.none) {
          totalMs -= ExportCommands.overlapMs(
            segments[i - 1].outputMs,
            segments[i].outputMs,
          );
        }
      }
      if (totalMs < 1) totalMs = 1;

      final bool hasTransitions = segments
          .skip(1)
          .any((Segment s) => s.transition != TransitionKind.none);
      final bool needsPass2 = layers.isNotEmpty ||
          overlays.isNotEmpty ||
          tracks.isNotEmpty ||
          (originalVolume - 1.0).abs() > 0.001;
      final double stage1Share = needsPass2 ? 0.55 : 0.95;
      final String finalPath = '${tmp.path}/Cutflow_$stamp.mp4';
      final String stage1 = needsPass2 ? '${work.path}/stage1.mp4' : finalPath;

      // ----- pass 1: render each clip -----
      final int clipsTotal =
          segments.fold<int>(0, (int a, Segment s) => a + s.outputMs);
      final List<String> parts = <String>[];
      int doneMs = 0;
      for (int i = 0; i < segments.length; i++) {
        final Segment s = segments[i];
        final String out = '${work.path}/part_$i.mp4';
        final int base = doneMs;
        final bool ok = await _ff.run(
          ExportCommands.segmentCommand(
            s: s,
            outPath: out,
            width: size[0],
            height: size[1],
            encoder: encoder,
          ),
          onTime: (int ms) {
            final int inPart = ms > s.outputMs ? s.outputMs : ms;
            final double p = (base + inPart) / clipsTotal;
            final double share = hasTransitions ? 0.7 : 1.0;
            onProgress((p * share * stage1Share).clamp(0.0, stage1Share).toDouble());
          },
        );
        if (!ok) return fail('Clip ${i + 1} could not be processed.');
        parts.add(out);
        doneMs += s.outputMs;
      }

      // ----- join the clips -----
      if (parts.length == 1) {
        await File(parts.first).copy(stage1);
      } else if (hasTransitions) {
        final bool ok = await _ff.run(
          ExportCommands.joinCommand(
            parts: parts,
            segments: segments,
            outPath: stage1,
            encoder: encoder,
          ),
          onTime: (int ms) {
            final double p = 0.7 + 0.3 * (ms / totalMs);
            onProgress((p * stage1Share).clamp(0.0, stage1Share).toDouble());
          },
        );
        if (!ok) return fail('The clips could not be joined with transitions.');
      } else {
        final File list = File('${work.path}/list.txt');
        await list.writeAsString(ExportCommands.concatList(parts));
        final bool ok = await _ff.run(
          '-y -f concat -safe 0 -i "${list.path}" -c copy '
          '-movflags +faststart "$stage1"',
        );
        if (!ok) return fail('The clips could not be joined.');
      }
      onProgress(stage1Share);

      // ----- pass 2: layers, text, stickers, captions and sound -----
      if (needsPass2) {
        final List<LayerInput> pips = <LayerInput>[
          for (final PipLayer l in layers)
            if (l.startMs < totalMs)
              LayerInput(
                path: l.path,
                isVideo: l.isVideo,
                cx: l.cx,
                cy: l.cy,
                widthPx: (size[0] * l.widthFrac).round() - ((size[0] * l.widthFrac).round() % 2),
                startMs: l.startMs,
                endMs: l.endMs > totalMs ? totalMs : l.endMs,
              ),
        ];
        final List<OverlayInput> pictures = <OverlayInput>[];
        for (int i = 0; i < overlays.length; i++) {
          final ClipOverlay o = overlays[i];
          if (o.startMs >= totalMs) continue;
          final RenderedOverlay r = await OverlayRenderer.render(
            overlay: o,
            canvasW: size[0],
            canvasH: size[1],
            outPath: '${work.path}/overlay_$i.png',
          );
          pictures.add(OverlayInput(
            path: r.path,
            x: (o.cx * size[0] - r.width / 2).round(),
            y: (o.cy * size[1] - r.height / 2).round(),
            startMs: o.startMs,
            endMs: o.endMs > totalMs ? totalMs : o.endMs,
          ));
        }
        final List<TrackInput> sounds = <TrackInput>[
          for (final AudioTrack t in tracks)
            if (t.startMs < totalMs)
              TrackInput(path: t.path, delayMs: t.startMs, volume: t.volume),
        ];
        onProgress(stage1Share + 0.03);
        final bool ok = await _ff.run(
          ExportCommands.finalPassCommand(
            inPath: stage1,
            outPath: finalPath,
            layers: pips,
            overlays: pictures,
            tracks: sounds,
            originalVolume: originalVolume,
            encoder: encoder,
          ),
          onTime: (int ms) {
            final double p = stage1Share + 0.03 + 0.37 * (ms / totalMs);
            onProgress(p.clamp(0.0, 0.96).toDouble());
          },
        );
        if (!ok) {
          return fail('Layers, text, captions or sound could not be added.');
        }
      }
      onProgress(0.97);

      try {
        await Gal.putVideo(finalPath, album: 'Cutflow');
      } catch (e) {
        return ExportResult(
          ok: false,
          path: finalPath,
          message: 'The video was made but could not be saved to your gallery: $e',
        );
      }
      onProgress(1.0);
      return ExportResult(
        ok: true,
        path: finalPath,
        message: hardware
            ? 'Saved to your gallery, in the Cutflow album.'
            : 'Saved to your gallery, in the Cutflow album. '
                '(Compatibility mode was used, so it took longer.)',
      );
    } catch (e) {
      return ExportResult(
        ok: false,
        message: _ff.failText('Export failed: $e'),
      );
    } finally {
      try {
        await work?.delete(recursive: true);
      } catch (_) {}
    }
  }

  static void stop() {
    FFmpegKit.cancel();
  }
}
