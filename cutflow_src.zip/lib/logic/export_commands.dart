import 'models.dart';

/// One picture (rendered text or sticker) to lay over the video.
class OverlayInput {
  const OverlayInput({
    required this.path,
    required this.x,
    required this.y,
    required this.startMs,
    required this.endMs,
  });

  final String path;
  final int x;
  final int y;
  final int startMs;
  final int endMs;
}

/// One extra sound (music or voice-over) to mix into the video.
class TrackInput {
  const TrackInput({
    required this.path,
    required this.delayMs,
    required this.volume,
  });

  final String path;
  final int delayMs;
  final double volume;
}

/// Builds the FFmpeg command text. Pure Dart, so it can be unit tested.
class ExportCommands {
  ExportCommands._();

  static int _even(double v) {
    final int i = v.round();
    return i - (i % 2);
  }

  /// Output size for a canvas shape. [shortSide] is 480, 720 or 1080.
  static List<int> canvasSize(CropPreset canvas, int shortSide) {
    final double a = canvas.ratio ?? (16 / 9);
    if (a >= 1) {
      return <int>[_even(shortSide * a), shortSide];
    }
    return <int>[shortSide, _even(shortSide / a)];
  }

  /// FFmpeg's atempo only accepts 0.5 to 2.0, so bigger/smaller speeds chain.
  static String atempoChain(double speed) {
    if ((speed - 1.0).abs() < 0.001) return '';
    final List<String> parts = <String>[];
    double s = speed;
    while (s > 2.0) {
      parts.add('atempo=2.0');
      s /= 2.0;
    }
    while (s < 0.5) {
      parts.add('atempo=0.5');
      s /= 0.5;
    }
    parts.add('atempo=${s.toStringAsFixed(3)}');
    return parts.join(',');
  }

  /// Renders one segment into a standard-format MP4 (same size, 30 fps,
  /// AAC audio) so all pieces can be joined without re-encoding.
  static String segmentCommand({
    required Segment s,
    required String outPath,
    required int width,
    required int height,
  }) {
    final String ss = (s.startMs / 1000).toStringAsFixed(3);
    final String dur = (s.trimmedMs / 1000).toStringAsFixed(3);
    final String outDur = (s.outputMs / 1000).toStringAsFixed(3);
    final String sp = s.speed.toStringAsFixed(4);

    final List<String> vf = <String>[];
    switch (s.rotation % 360) {
      case 90:
        vf.add('transpose=1');
        break;
      case 180:
        vf.add('transpose=1');
        vf.add('transpose=1');
        break;
      case 270:
        vf.add('transpose=2');
        break;
      default:
        break;
    }
    final double? r = s.crop.ratio;
    if (r != null) {
      final String rs = r.toStringAsFixed(6);
      vf.add("crop=w='trunc(min(iw,ih*$rs)/2)*2':h='trunc(min(ih,iw/$rs)/2)*2'");
    }
    vf.add('setpts=PTS/$sp');
    vf.add('scale=$width:$height:force_original_aspect_ratio=decrease:force_divisible_by=2');
    final String? look = s.filter.ffmpeg;
    if (look != null) vf.add(look);
    vf.add('pad=$width:$height:(ow-iw)/2:(oh-ih)/2:color=black');
    vf.add('setsar=1');
    vf.add('fps=30');
    vf.add('format=yuv420p');

    final String tempo = atempoChain(s.speed);
    final String af = tempo.isEmpty ? 'aresample=44100' : '$tempo,aresample=44100';

    final StringBuffer b = StringBuffer('-y -ss $ss -t $dur -i "${s.path}" ');
    if (!s.hasAudio) {
      b.write('-f lavfi -t $outDur -i anullsrc=channel_layout=stereo:sample_rate=44100 ');
    }
    b.write('-map 0:v:0 ');
    b.write(s.hasAudio ? '-map 0:a:0 ' : '-map 1:a:0 ');
    b.write('-vf "${vf.join(',')}" -af "$af" ');
    b.write('-c:v libx264 -preset superfast -crf 25 -pix_fmt yuv420p ');
    b.write('-c:a aac -b:a 128k -ar 44100 -ac 2 ');
    b.write('-t $outDur "$outPath"');
    return b.toString();
  }

  /// Second pass: lays overlays on the joined video and mixes the sound.
  /// Video is copied untouched if there are no overlays, and audio is copied
  /// untouched if nothing about the sound changed.
  static String finalPassCommand({
    required String inPath,
    required String outPath,
    required List<OverlayInput> overlays,
    required List<TrackInput> tracks,
    required double originalVolume,
  }) {
    final bool videoWork = overlays.isNotEmpty;
    final bool audioWork =
        tracks.isNotEmpty || (originalVolume - 1.0).abs() > 0.001;

    final StringBuffer b = StringBuffer('-y -i "$inPath" ');
    for (final OverlayInput o in overlays) {
      b.write('-i "${o.path}" ');
    }
    for (final TrackInput t in tracks) {
      b.write('-i "${t.path}" ');
    }

    final List<String> graph = <String>[];
    if (videoWork) {
      String last = '0:v';
      for (int i = 0; i < overlays.length; i++) {
        final OverlayInput o = overlays[i];
        final String out = 'v${i + 1}';
        final String a = (o.startMs / 1000).toStringAsFixed(3);
        final String e = (o.endMs / 1000).toStringAsFixed(3);
        graph.add(
          "[$last][${i + 1}:v]overlay=x=${o.x}:y=${o.y}:enable='between(t,$a,$e)'[$out]",
        );
        last = out;
      }
      graph.add('[$last]format=yuv420p[vout]');
    }
    if (audioWork) {
      graph.add('[0:a]volume=${originalVolume.toStringAsFixed(3)}[a0]');
      final List<String> labels = <String>['[a0]'];
      for (int i = 0; i < tracks.length; i++) {
        final TrackInput t = tracks[i];
        final int input = 1 + overlays.length + i;
        graph.add(
          '[$input:a]adelay=${t.delayMs}:all=1,'
          'volume=${t.volume.toStringAsFixed(3)},aresample=44100[t$i]',
        );
        labels.add('[t$i]');
      }
      if (labels.length == 1) {
        graph.add('[a0]anull[aout]');
      } else {
        graph.add(
          '${labels.join()}amix=inputs=${labels.length}:duration=first:normalize=0[aout]',
        );
      }
    }
    if (graph.isNotEmpty) {
      b.write('-filter_complex "${graph.join(';')}" ');
    }
    b.write(videoWork ? '-map "[vout]" ' : '-map 0:v ');
    b.write(audioWork ? '-map "[aout]" ' : '-map 0:a ');
    b.write(videoWork
        ? '-c:v libx264 -preset superfast -crf 25 -pix_fmt yuv420p '
        : '-c:v copy ');
    b.write(audioWork ? '-c:a aac -b:a 160k -ar 44100 ' : '-c:a copy ');
    b.write('-movflags +faststart "$outPath"');
    return b.toString();
  }

  static String concatList(List<String> paths) {
    return paths.map((String p) => "file '$p'").join('\n');
  }
}
