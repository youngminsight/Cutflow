import 'dart:math' as math;

import 'models.dart';

/// One picture (rendered text or sticker) to lay over the video.
class OverlayInput {
  const OverlayInput({
    required this.path,
    required this.x,
    required this.y,
    required this.startMs,
    required this.endMs,
  });

  final String path;
  final int x;
  final int y;
  final int startMs;
  final int endMs;
}

/// One picture-in-picture photo or video.
class LayerInput {
  const LayerInput({
    required this.path,
    required this.isVideo,
    required this.cx,
    required this.cy,
    required this.widthPx,
    required this.startMs,
    required this.endMs,
  });

  final String path;
  final bool isVideo;
  final double cx;
  final double cy;
  final int widthPx;
  final int startMs;
  final int endMs;
}

/// One extra sound (music or voice-over) to mix into the video.
class TrackInput {
  const TrackInput({
    required this.path,
    required this.delayMs,
    required this.volume,
  });

  final String path;
  final int delayMs;
  final double volume;
}

/// Builds the FFmpeg command text. Pure Dart, so it can be unit tested.
/// These exact commands were also run against a real FFmpeg before release.
class ExportCommands {
  ExportCommands._();

  static int _even(double v) {
    final int i = v.round();
    return i - (i % 2);
  }

  /// Phone video chip when available, with a software fallback.
  static String videoEncoder({required bool hardware, required int shortSide}) {
    if (hardware) {
      final int kbps = shortSide <= 480 ? 2000 : (shortSide <= 720 ? 4000 : 8000);
      return '-c:v h264_mediacodec -b:v ${kbps}k';
    }
    return '-c:v mpeg4 -q:v 4';
  }

  /// How long a transition between two clips overlaps them, in ms.
  static int overlapMs(int prevMs, int curMs) {
    return math.min(500, math.min(prevMs ~/ 2, curMs ~/ 2));
  }

  /// Output size for a canvas shape. [shortSide] is 480, 720 or 1080.
  static List<int> canvasSize(CropPreset canvas, int shortSide) {
    final double a = canvas.ratio ?? (16 / 9);
    if (a >= 1) {
      return <int>[_even(shortSide * a), shortSide];
    }
    return <int>[shortSide, _even(shortSide / a)];
  }

  /// FFmpeg's atempo only accepts 0.5 to 2.0, so bigger/smaller speeds chain.
  static String atempoChain(double speed) {
    if ((speed - 1.0).abs() < 0.001) return '';
    final List<String> parts = <String>[];
    double s = speed;
    while (s > 2.0) {
      parts.add('atempo=2.0');
      s /= 2.0;
    }
    while (s < 0.5) {
      parts.add('atempo=0.5');
      s /= 0.5;
    }
    parts.add('atempo=${s.toStringAsFixed(3)}');
    return parts.join(',');
  }

  /// Renders one segment into a standard-format MP4 (same size, 30 fps,
  /// AAC audio) so all pieces can be joined afterwards.
  static String segmentCommand({
    required Segment s,
    required String outPath,
    required int width,
    required int height,
    required String encoder,
  }) {
    final String ss = (s.startMs / 1000).toStringAsFixed(3);
    final String dur = (s.trimmedMs / 1000).toStringAsFixed(3);
    final String outDur = (s.outputMs / 1000).toStringAsFixed(3);
    final String sp = s.speed.toStringAsFixed(4);

    final List<String> vf = <String>[];
    switch (s.rotation % 360) {
      case 90:
        vf.add('transpose=1');
        break;
      case 180:
        vf.add('transpose=1');
        vf.add('transpose=1');
        break;
      case 270:
        vf.add('transpose=2');
        break;
      default:
        break;
    }
    final double? r = s.crop.ratio;
    if (r != null) {
      final String rs = r.toStringAsFixed(6);
      vf.add("crop=w='trunc(min(iw,ih*$rs)/2)*2':h='trunc(min(ih,iw/$rs)/2)*2'");
    }
    vf.add('setpts=PTS/$sp');
    vf.add('scale=$width:$height:force_original_aspect_ratio=decrease:force_divisible_by=2');
    final String? look = s.filter.ffmpeg;
    if (look != null) vf.add(look);
    vf.add('pad=$width:$height:(ow-iw)/2:(oh-ih)/2:color=black');
    vf.add('setsar=1');
    vf.add('fps=30');

    final String tempo = atempoChain(s.speed);
    final String af = tempo.isEmpty ? 'aresample=44100' : '$tempo,aresample=44100';

    final StringBuffer b = StringBuffer('-y -ss $ss -t $dur -i "${s.path}" ');
    if (!s.hasAudio) {
      b.write('-f lavfi -t $outDur -i anullsrc=channel_layout=stereo:sample_rate=44100 ');
    }
    b.write('-map 0:v:0 ');
    b.write(s.hasAudio ? '-map 0:a:0 ' : '-map 1:a:0 ');
    b.write('-vf "${vf.join(',')}" -af "$af" ');
    b.write('$encoder -c:a aac -b:a 128k -ar 44100 -ac 2 ');
    b.write('-t $outDur "$outPath"');
    return b.toString();
  }

  static String concatList(List<String> paths) {
    return paths.map((String p) => "file '$p'").join('\n');
  }

  /// Joins the rendered clips with transitions in one pass. Clips joined by a
  /// plain cut are first grouped with the concat filter, then groups are
  /// blended with xfade (picture) and acrossfade (sound).
  static String joinCommand({
    required List<String> parts,
    required List<Segment> segments,
    required String outPath,
    required String encoder,
  }) {
    final List<List<int>> groups = <List<int>>[
      <int>[0],
    ];
    for (int i = 1; i < segments.length; i++) {
      if (segments[i].transition == TransitionKind.none) {
        groups.last.add(i);
      } else {
        groups.add(<int>[i]);
      }
    }

    final StringBuffer b = StringBuffer('-y ');
    for (final String p in parts) {
      b.write('-i "$p" ');
    }

    final List<String> g = <String>[];
    final List<String> vl = <String>[];
    final List<String> al = <String>[];
    final List<int> ln = <int>[];
    for (int k = 0; k < groups.length; k++) {
      final List<int> idx = groups[k];
      ln.add(idx.fold<int>(0, (int a, int i) => a + segments[i].outputMs));
      if (idx.length == 1) {
        g.add('[${idx[0]}:v]fps=30,settb=AVTB[gv$k]');
        vl.add('[gv$k]');
        al.add('[${idx[0]}:a]');
      } else {
        final String ins = idx.map((int i) => '[$i:v][$i:a]').join();
        g.add('${ins}concat=n=${idx.length}:v=1:a=1[gv$k][ga$k]');
        vl.add('[gv$k]');
        al.add('[ga$k]');
      }
    }

    String accV = vl[0];
    String accA = al[0];
    int acc = ln[0];
    for (int k = 1; k < groups.length; k++) {
      final int first = groups[k][0];
      final int d = overlapMs(segments[first - 1].outputMs, segments[first].outputMs);
      final String t = segments[first].transition.xfade ?? 'fade';
      final String dur = (d / 1000).toStringAsFixed(3);
      final String off = ((acc - d) / 1000).toStringAsFixed(3);
      g.add('$accV${vl[k]}xfade=transition=$t:duration=$dur:offset=$off[xv$k]');
      g.add('$accA${al[k]}acrossfade=d=$dur[xa$k]');
      accV = '[xv$k]';
      accA = '[xa$k]';
      acc = acc + ln[k] - d;
    }

    b.write('-filter_complex "${g.join(';')}" ');
    b.write('-map "$accV" -map "$accA" ');
    b.write('$encoder -c:a aac -b:a 160k -ar 44100 ');
    b.write('"$outPath"');
    return b.toString();
  }

  /// Second pass: lays picture-in-picture layers, text and stickers on the
  /// joined video and mixes the sound. Video is copied untouched if there is
  /// nothing to lay over it, and audio is copied if the sound is unchanged.
  static String finalPassCommand({
    required String inPath,
    required String outPath,
    required List<LayerInput> layers,
    required List<OverlayInput> overlays,
    required List<TrackInput> tracks,
    required double originalVolume,
    required String encoder,
  }) {
    final bool videoWork = layers.isNotEmpty || overlays.isNotEmpty;
    final bool audioWork =
        tracks.isNotEmpty || (originalVolume - 1.0).abs() > 0.001;

    final StringBuffer b = StringBuffer('-y -i "$inPath" ');
    for (final LayerInput l in layers) {
      final String dur = ((l.endMs - l.startMs) / 1000).toStringAsFixed(3);
      if (l.isVideo) {
        b.write('-t $dur -i "${l.path}" ');
      } else {
        b.write('-loop 1 -framerate 30 -t $dur -i "${l.path}" ');
      }
    }
    for (final OverlayInput o in overlays) {
      b.write('-i "${o.path}" ');
    }
    for (final TrackInput t in tracks) {
      b.write('-i "${t.path}" ');
    }

    final List<String> graph = <String>[];
    String lastVideo = '0:v';
    if (videoWork) {
      int n = 0;
      for (int k = 0; k < layers.length; k++) {
        final LayerInput l = layers[k];
        final int input = 1 + k;
        n++;
        final String start = (l.startMs / 1000).toStringAsFixed(3);
        final String end = (l.endMs / 1000).toStringAsFixed(3);
        graph.add(
          '[$input:v]scale=${l.widthPx}:-2,setpts=PTS-STARTPTS+$start/TB[ly$k]',
        );
        graph.add(
          "[$lastVideo][ly$k]overlay=x='W*${l.cx.toStringAsFixed(4)}-w/2':"
          "y='H*${l.cy.toStringAsFixed(4)}-h/2':"
          "enable='between(t,$start,$end)'[v$n]",
        );
        lastVideo = 'v$n';
      }
      for (int k = 0; k < overlays.length; k++) {
        final OverlayInput o = overlays[k];
        final int input = 1 + layers.length + k;
        n++;
        final String a = (o.startMs / 1000).toStringAsFixed(3);
        final String e = (o.endMs / 1000).toStringAsFixed(3);
        graph.add(
          "[$lastVideo][$input:v]overlay=x=${o.x}:y=${o.y}:"
          "enable='between(t,$a,$e)'[v$n]",
        );
        lastVideo = 'v$n';
      }
    }
    if (audioWork) {
      graph.add('[0:a]volume=${originalVolume.toStringAsFixed(3)}[a0]');
      final List<String> labels = <String>['[a0]'];
      for (int i = 0; i < tracks.length; i++) {
        final TrackInput t = tracks[i];
        final int input = 1 + layers.length + overlays.length + i;
        graph.add(
          '[$input:a]adelay=${t.delayMs}:all=1,'
          'volume=${t.volume.toStringAsFixed(3)},aresample=44100[t$i]',
        );
        labels.add('[t$i]');
      }
      if (labels.length == 1) {
        graph.add('[a0]anull[aout]');
      } else {
        graph.add(
          '${labels.join()}amix=inputs=${labels.length}:duration=first:normalize=0[aout]',
        );
      }
    }
    if (graph.isNotEmpty) {
      b.write('-filter_complex "${graph.join(';')}" ');
    }
    b.write(videoWork ? '-map "[$lastVideo]" ' : '-map 0:v ');
    b.write(audioWork ? '-map "[aout]" ' : '-map 0:a ');
    b.write(videoWork ? '$encoder ' : '-c:v copy ');
    b.write(audioWork ? '-c:a aac -b:a 160k -ar 44100 ' : '-c:a copy ');
    b.write('"$outPath"');
    return b.toString();
  }

  /// Extracts one clip's sound as 16 kHz mono WAV for speech recognition.
  /// Silent clips become silence of the same length.
  static String captionPartCommand({required Segment s, required String outPath}) {
    final String outDur = (s.outputMs / 1000).toStringAsFixed(3);
    if (!s.hasAudio) {
      return '-y -f lavfi -t $outDur -i anullsrc=channel_layout=mono:sample_rate=16000 '
          '-c:a pcm_s16le "$outPath"';
    }
    final String ss = (s.startMs / 1000).toStringAsFixed(3);
    final String dur = (s.trimmedMs / 1000).toStringAsFixed(3);
    final String tempo = atempoChain(s.speed);
    final String af = tempo.isEmpty ? 'aresample=16000' : '$tempo,aresample=16000';
    return '-y -ss $ss -t $dur -i "${s.path}" -vn -af "$af" -ac 1 '
        '-c:a pcm_s16le "$outPath"';
  }
}
