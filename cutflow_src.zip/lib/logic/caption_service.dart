import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:whisper_wrapper/whisper_wrapper.dart';

import 'export_commands.dart';
import 'export_service.dart';
import 'models.dart';

/// One caption line, with times measured on the plain end-to-end audio.
class CaptionLine {
  const CaptionLine({
    required this.text,
    required this.startMs,
    required this.endMs,
  });

  final String text;
  final int startMs;
  final int endMs;
}

/// Turns the speech in the timeline into caption lines, fully on the phone.
/// The English speech model is downloaded once (needs internet that one time).
class CaptionService {
  CaptionService._();

  static Future<List<CaptionLine>> transcribe({
    required List<Segment> segments,
    required bool better,
    required void Function(String status) onStatus,
    required void Function(double progress) onProgress,
  }) async {
    final FfmpegRunner ff = FfmpegRunner();
    final Directory tmp = await getTemporaryDirectory();
    final String stamp = DateTime.now().millisecondsSinceEpoch.toString();
    final Directory work =
        await Directory('${tmp.path}/captions_$stamp').create(recursive: true);
    try {
      onStatus('Preparing the sound...');
      final List<String> parts = <String>[];
      for (int i = 0; i < segments.length; i++) {
        final String out = '${work.path}/c$i.wav';
        final bool ok = await ff.run(
          ExportCommands.captionPartCommand(s: segments[i], outPath: out),
        );
        if (!ok) throw StateError(ff.failText('Could not read the sound.'));
        parts.add(out);
      }
      String wav = parts.first;
      if (parts.length > 1) {
        final File list = File('${work.path}/list.txt');
        await list.writeAsString(ExportCommands.concatList(parts));
        wav = '${work.path}/all.wav';
        final bool ok = await ff.run(
          '-y -f concat -safe 0 -i "${list.path}" -c copy "$wav"',
        );
        if (!ok) throw StateError(ff.failText('Could not join the sound.'));
      }

      onStatus(
        better
            ? 'Listening... the first time this downloads the speech model (about 140 MB).'
            : 'Listening... the first time this downloads the speech model (about 75 MB).',
      );
      final WhisperController controller = WhisperController();
      final dynamic result = await controller.transcribe(
        model: better ? WhisperModel.baseEn : WhisperModel.tinyEn,
        audioPath: wav,
        lang: 'en',
        withSegments: true,
        onProgress: (dynamic p) {
          if (p is num) onProgress((p / 100).clamp(0.0, 1.0).toDouble());
        },
      );

      final List<CaptionLine> lines = <CaptionLine>[];
      final dynamic found = result?.transcription.segments;
      if (found != null) {
        for (final dynamic s in found) {
          final String text = (s.text as String).trim();
          if (text.isEmpty || text.startsWith('[') || text.startsWith('(')) {
            continue;
          }
          final int from = (s.fromTs as Duration).inMilliseconds;
          final int to = (s.toTs as Duration).inMilliseconds;
          lines.add(CaptionLine(text: text, startMs: from, endMs: to));
        }
      }
      return lines;
    } finally {
      try {
        await work.delete(recursive: true);
      } catch (_) {}
    }
  }
}
