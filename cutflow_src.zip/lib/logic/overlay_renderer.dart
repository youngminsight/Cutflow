import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'models.dart';

class RenderedOverlay {
  const RenderedOverlay({
    required this.path,
    required this.width,
    required this.height,
  });

  final String path;
  final int width;
  final int height;
}

/// Draws text or an emoji into a transparent PNG at export size.
/// Using pictures (not FFmpeg fonts) means any font, emoji or language works
/// and the result matches what the preview shows.
class OverlayRenderer {
  OverlayRenderer._();

  static Future<RenderedOverlay> render({
    required ClipOverlay overlay,
    required int canvasW,
    required int canvasH,
    required String outPath,
  }) async {
    final double fontSize = overlay.sizeFrac * canvasH;
    final bool isText = overlay.kind == OverlayKind.text;
    final FontWeight weight = isText ? FontWeight.w800 : FontWeight.w400;

    final TextPainter fill = TextPainter(
      text: TextSpan(
        text: overlay.text,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: weight,
          color: Color(overlay.colorValue),
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout(maxWidth: canvasW * 0.9);

    final double pad = fontSize * 0.25;
    final int w = (fill.width + pad * 2).ceil();
    final int h = (fill.height + pad * 2).ceil();

    final ui.PictureRecorder recorder = ui.PictureRecorder();
    final Canvas canvas = Canvas(recorder);

    if (isText) {
      final TextPainter outline = TextPainter(
        text: TextSpan(
          text: overlay.text,
          style: TextStyle(
            fontSize: fontSize,
            fontWeight: weight,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = fontSize * 0.12
              ..color = const Color(0xFF000000),
          ),
        ),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      )..layout(maxWidth: canvasW * 0.9);
      outline.paint(canvas, Offset(pad, pad));
    }
    fill.paint(canvas, Offset(pad, pad));

    final ui.Image image = await recorder.endRecording().toImage(w, h);
    final ByteData? data =
        await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) {
      throw StateError('Could not draw the overlay picture.');
    }
    await File(outPath).writeAsBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
    );
    return RenderedOverlay(path: outPath, width: w, height: h);
  }
}
