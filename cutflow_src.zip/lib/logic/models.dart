/// Crop shapes, also used as export canvas shapes.
enum CropPreset { original, vertical, square, landscape, portrait }

extension CropPresetInfo on CropPreset {
  String get label => switch (this) {
        CropPreset.original => 'Original',
        CropPreset.vertical => '9:16 Vertical',
        CropPreset.square => '1:1 Square',
        CropPreset.landscape => '16:9 Wide',
        CropPreset.portrait => '4:5 Portrait',
      };

  /// width / height, or null for "keep as it is".
  double? get ratio => switch (this) {
        CropPreset.original => null,
        CropPreset.vertical => 9 / 16,
        CropPreset.square => 1.0,
        CropPreset.landscape => 16 / 9,
        CropPreset.portrait => 4 / 5,
      };
}

/// Colour looks for a clip. `ffmpeg` is the real export filter;
/// `previewMatrix` is an approximate look for the on-screen preview.
enum FilterPreset { none, blackWhite, sepia, warm, cool, vivid, vintage, faded }

const String _sepiaMixer =
    'colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131';

extension FilterPresetInfo on FilterPreset {
  String get label => switch (this) {
        FilterPreset.none => 'None',
        FilterPreset.blackWhite => 'Black & white',
        FilterPreset.sepia => 'Sepia',
        FilterPreset.warm => 'Warm',
        FilterPreset.cool => 'Cool',
        FilterPreset.vivid => 'Vivid',
        FilterPreset.vintage => 'Vintage',
        FilterPreset.faded => 'Faded',
      };

  String? get ffmpeg => switch (this) {
        FilterPreset.none => null,
        FilterPreset.blackWhite => 'hue=s=0',
        FilterPreset.sepia => _sepiaMixer,
        FilterPreset.warm =>
          'colorbalance=rs=0.08:rm=0.12:rh=0.08:bs=-0.08:bm=-0.12:bh=-0.08',
        FilterPreset.cool =>
          'colorbalance=rs=-0.06:rm=-0.1:rh=-0.06:bs=0.1:bm=0.15:bh=0.1',
        FilterPreset.vivid => 'eq=saturation=1.5:contrast=1.08',
        FilterPreset.vintage => '$_sepiaMixer,vignette',
        FilterPreset.faded => 'eq=brightness=0.04:contrast=0.88:saturation=0.8',
      };

  List<double>? get previewMatrix => switch (this) {
        FilterPreset.none => null,
        FilterPreset.blackWhite => <double>[
            0.2126, 0.7152, 0.0722, 0, 0,
            0.2126, 0.7152, 0.0722, 0, 0,
            0.2126, 0.7152, 0.0722, 0, 0,
            0, 0, 0, 1, 0,
          ],
        FilterPreset.sepia || FilterPreset.vintage => <double>[
            0.393, 0.769, 0.189, 0, 0,
            0.349, 0.686, 0.168, 0, 0,
            0.272, 0.534, 0.131, 0, 0,
            0, 0, 0, 1, 0,
          ],
        FilterPreset.warm => <double>[
            1.1, 0, 0, 0, 0,
            0, 1.0, 0, 0, 0,
            0, 0, 0.88, 0, 0,
            0, 0, 0, 1, 0,
          ],
        FilterPreset.cool => <double>[
            0.9, 0, 0, 0, 0,
            0, 1.0, 0, 0, 0,
            0, 0, 1.12, 0, 0,
            0, 0, 0, 1, 0,
          ],
        FilterPreset.vivid => <double>[
            1.3937, -0.3576, -0.0361, 0, 0,
            -0.1063, 1.1424, -0.0361, 0, 0,
            -0.1063, -0.3576, 1.4639, 0, 0,
            0, 0, 0, 1, 0,
          ],
        FilterPreset.faded => <double>[
            0.85, 0, 0, 0, 20,
            0, 0.85, 0, 0, 20,
            0, 0, 0.85, 0, 20,
            0, 0, 0, 1, 0,
          ],
      };
}

/// How a clip blends in from the clip before it.
enum TransitionKind {
  none,
  fade,
  wipeLeft,
  wipeRight,
  slideLeft,
  slideRight,
  circleOpen,
  dissolve,
  dipBlack,
}

extension TransitionKindInfo on TransitionKind {
  String get label => switch (this) {
        TransitionKind.none => 'None (cut)',
        TransitionKind.fade => 'Fade',
        TransitionKind.wipeLeft => 'Wipe left',
        TransitionKind.wipeRight => 'Wipe right',
        TransitionKind.slideLeft => 'Slide left',
        TransitionKind.slideRight => 'Slide right',
        TransitionKind.circleOpen => 'Circle open',
        TransitionKind.dissolve => 'Dissolve',
        TransitionKind.dipBlack => 'Dip to black',
      };

  /// Name of the matching FFmpeg xfade transition.
  String? get xfade => switch (this) {
        TransitionKind.none => null,
        TransitionKind.fade => 'fade',
        TransitionKind.wipeLeft => 'wipeleft',
        TransitionKind.wipeRight => 'wiperight',
        TransitionKind.slideLeft => 'slideleft',
        TransitionKind.slideRight => 'slideright',
        TransitionKind.circleOpen => 'circleopen',
        TransitionKind.dissolve => 'dissolve',
        TransitionKind.dipBlack => 'fadeblack',
      };
}

const List<double> kSpeeds = <double>[0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0];

/// One piece of the timeline: part of a source video plus its settings.
class Segment {
  const Segment({
    required this.path,
    required this.sourceMs,
    required this.hasAudio,
    required this.startMs,
    required this.endMs,
    this.speed = 1.0,
    this.rotation = 0,
    this.crop = CropPreset.original,
    this.filter = FilterPreset.none,
    this.transition = TransitionKind.none,
  });

  final String path;
  final int sourceMs;
  final bool hasAudio;
  final int startMs;
  final int endMs;
  final double speed;
  final int rotation; // 0, 90, 180 or 270 degrees clockwise
  final CropPreset crop;
  final FilterPreset filter;

  /// Blend from the previous clip into this one (ignored on the first clip).
  final TransitionKind transition;

  int get trimmedMs => endMs - startMs;

  /// Length of this piece in the finished video (after speed change).
  int get outputMs => (trimmedMs / speed).round();

  Segment copyWith({
    int? startMs,
    int? endMs,
    double? speed,
    int? rotation,
    CropPreset? crop,
    FilterPreset? filter,
    TransitionKind? transition,
  }) {
    return Segment(
      path: path,
      sourceMs: sourceMs,
      hasAudio: hasAudio,
      startMs: startMs ?? this.startMs,
      endMs: endMs ?? this.endMs,
      speed: speed ?? this.speed,
      rotation: rotation ?? this.rotation,
      crop: crop ?? this.crop,
      filter: filter ?? this.filter,
      transition: transition ?? this.transition,
    );
  }
}

enum OverlayKind { text, sticker }

/// Text or an emoji sticker shown on the finished video for a time range.
/// Times are on the final (joined) timeline. cx, cy are the centre point as
/// fractions (0 to 1) of the video frame. sizeFrac is the text height as a
/// fraction of the frame height.
class ClipOverlay {
  const ClipOverlay({
    required this.id,
    required this.kind,
    required this.text,
    required this.startMs,
    required this.endMs,
    this.cx = 0.5,
    this.cy = 0.5,
    this.sizeFrac = 0.06,
    this.colorValue = 0xFFFFFFFF,
    this.isCaption = false,
  });

  final String id;
  final OverlayKind kind;
  final String text;
  final int startMs;
  final int endMs;
  final double cx;
  final double cy;
  final double sizeFrac;
  final int colorValue;

  /// True for lines made by auto captions (managed together in Captions).
  final bool isCaption;

  ClipOverlay copyWith({
    String? text,
    int? startMs,
    int? endMs,
    double? cx,
    double? cy,
    double? sizeFrac,
    int? colorValue,
  }) {
    return ClipOverlay(
      id: id,
      kind: kind,
      text: text ?? this.text,
      startMs: startMs ?? this.startMs,
      endMs: endMs ?? this.endMs,
      cx: cx ?? this.cx,
      cy: cy ?? this.cy,
      sizeFrac: sizeFrac ?? this.sizeFrac,
      colorValue: colorValue ?? this.colorValue,
      isCaption: isCaption,
    );
  }
}

/// A photo or video shown small on top of the main video (picture in picture).
/// Times are on the final timeline. cx, cy are the centre as fractions of the
/// frame; widthFrac is its width as a fraction of the frame width.
class PipLayer {
  const PipLayer({
    required this.id,
    required this.path,
    required this.isVideo,
    required this.startMs,
    required this.endMs,
    this.cx = 0.75,
    this.cy = 0.25,
    this.widthFrac = 0.35,
  });

  final String id;
  final String path;
  final bool isVideo;
  final int startMs;
  final int endMs;
  final double cx;
  final double cy;
  final double widthFrac;

  PipLayer copyWith({
    int? startMs,
    int? endMs,
    double? cx,
    double? cy,
    double? widthFrac,
  }) {
    return PipLayer(
      id: id,
      path: path,
      isVideo: isVideo,
      startMs: startMs ?? this.startMs,
      endMs: endMs ?? this.endMs,
      cx: cx ?? this.cx,
      cy: cy ?? this.cy,
      widthFrac: widthFrac ?? this.widthFrac,
    );
  }
}

enum TrackKind { music, voice }

/// A sound added on top of the video: music or a voice-over.
class AudioTrack {
  const AudioTrack({
    required this.id,
    required this.kind,
    required this.path,
    required this.label,
    required this.startMs,
    this.volume = 1.0,
  });

  final String id;
  final TrackKind kind;
  final String path;
  final String label;
  final int startMs;
  final double volume;

  AudioTrack copyWith({int? startMs, double? volume}) {
    return AudioTrack(
      id: id,
      kind: kind,
      path: path,
      label: label,
      startMs: startMs ?? this.startMs,
      volume: volume ?? this.volume,
    );
  }
}

String formatMs(int ms) {
  final int total = (ms / 1000).round();
  final int m = total ~/ 60;
  final int s = total % 60;
  return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
}
