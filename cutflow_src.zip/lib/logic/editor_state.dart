import 'package:flutter/foundation.dart';

import 'export_commands.dart';
import 'models.dart';

/// The project: an ordered list of segments and which one is selected.
class EditorState extends ChangeNotifier {
  final List<Segment> segments = <Segment>[];
  final List<ClipOverlay> overlays = <ClipOverlay>[];
  final List<AudioTrack> tracks = <AudioTrack>[];
  final List<PipLayer> layers = <PipLayer>[];
  int selected = -1;
  CropPreset canvas = CropPreset.vertical;
  double originalVolume = 1.0;
  String? selectedOverlayId;
  int _nextId = 1;

  String newId() => '${_nextId++}';

  Segment? get current =>
      (selected >= 0 && selected < segments.length) ? segments[selected] : null;

  /// How long clip [i] overlaps the clip before it (its transition).
  int overlapAt(int i) {
    if (i <= 0 || i >= segments.length) return 0;
    if (segments[i].transition == TransitionKind.none) return 0;
    return ExportCommands.overlapMs(
      segments[i - 1].outputMs,
      segments[i].outputMs,
    );
  }

  int get totalOutputMs {
    int sum = 0;
    for (int i = 0; i < segments.length; i++) {
      sum += segments[i].outputMs - overlapAt(i);
    }
    return sum;
  }

  void add(Segment s) {
    segments.add(s);
    selected = segments.length - 1;
    notifyListeners();
  }

  void select(int index) {
    if (index < 0 || index >= segments.length) return;
    selected = index;
    notifyListeners();
  }

  void updateCurrent(Segment s) {
    if (current == null) return;
    segments[selected] = s;
    notifyListeners();
  }

  /// Splits the selected segment at [positionMs] (a time in the source video).
  /// Returns false if the cut is too close to either end.
  bool splitAt(int positionMs) {
    final Segment? c = current;
    if (c == null) return false;
    if (positionMs - c.startMs < 300 || c.endMs - positionMs < 300) {
      return false;
    }
    segments[selected] = c.copyWith(endMs: positionMs);
    segments.insert(
      selected + 1,
      c.copyWith(startMs: positionMs, transition: TransitionKind.none),
    );
    notifyListeners();
    return true;
  }

  void deleteCurrent() {
    if (current == null) return;
    segments.removeAt(selected);
    if (segments.isEmpty) {
      selected = -1;
    } else if (selected >= segments.length) {
      selected = segments.length - 1;
    }
    notifyListeners();
  }

  void moveCurrent(int delta) {
    final int to = selected + delta;
    if (current == null || to < 0 || to >= segments.length) return;
    final Segment s = segments.removeAt(selected);
    segments.insert(to, s);
    selected = to;
    notifyListeners();
  }

  // ---------- time ----------

  /// Time on the final video for a playhead position inside segment [index].
  int globalMsFor(int index, int positionMs) {
    if (index < 0 || index >= segments.length) return 0;
    int sum = 0;
    for (int i = 0; i < index; i++) {
      sum += segments[i].outputMs;
    }
    for (int i = 1; i <= index; i++) {
      sum -= overlapAt(i);
    }
    final Segment s = segments[index];
    final int within = (positionMs - s.startMs).clamp(0, s.trimmedMs).toInt();
    return sum + (within / s.speed).round();
  }

  /// Converts a time in the plain end-to-end audio (used for captions) to a
  /// time on the final timeline, which is shorter where clips overlap.
  int timelineFromConcat(int concatMs) {
    int start = 0;
    int shift = 0;
    for (int i = 0; i < segments.length; i++) {
      shift += overlapAt(i);
      final int end = start + segments[i].outputMs;
      if (concatMs < end || i == segments.length - 1) {
        return (concatMs - shift).clamp(0, totalOutputMs).toInt();
      }
      start = end;
    }
    return 0;
  }

  // ---------- project settings ----------

  void setCanvas(CropPreset p) {
    if (p == CropPreset.original) return;
    canvas = p;
    notifyListeners();
  }

  void setOriginalVolume(double v) {
    originalVolume = v;
    notifyListeners();
  }

  // ---------- overlays ----------

  ClipOverlay? overlayById(String id) {
    for (final ClipOverlay o in overlays) {
      if (o.id == id) return o;
    }
    return null;
  }

  void addOverlay(ClipOverlay o) {
    overlays.add(o);
    selectedOverlayId = o.id;
    notifyListeners();
  }

  void updateOverlay(ClipOverlay o) {
    final int i = overlays.indexWhere((ClipOverlay x) => x.id == o.id);
    if (i < 0) return;
    overlays[i] = o;
    notifyListeners();
  }

  void deleteOverlay(String id) {
    overlays.removeWhere((ClipOverlay x) => x.id == id);
    if (selectedOverlayId == id) selectedOverlayId = null;
    notifyListeners();
  }

  void selectOverlay(String? id) {
    if (selectedOverlayId == id) return;
    selectedOverlayId = id;
    notifyListeners();
  }

  // ---------- audio tracks ----------

  AudioTrack? trackById(String id) {
    for (final AudioTrack t in tracks) {
      if (t.id == id) return t;
    }
    return null;
  }

  void addTrack(AudioTrack t) {
    tracks.add(t);
    notifyListeners();
  }

  void updateTrack(AudioTrack t) {
    final int i = tracks.indexWhere((AudioTrack x) => x.id == t.id);
    if (i < 0) return;
    tracks[i] = t;
    notifyListeners();
  }

  void deleteTrack(String id) {
    tracks.removeWhere((AudioTrack x) => x.id == id);
    notifyListeners();
  }

  // ---------- picture-in-picture layers ----------

  PipLayer? layerById(String id) {
    for (final PipLayer l in layers) {
      if (l.id == id) return l;
    }
    return null;
  }

  void addLayer(PipLayer l) {
    layers.add(l);
    selectedOverlayId = l.id;
    notifyListeners();
  }

  void updateLayer(PipLayer l) {
    final int i = layers.indexWhere((PipLayer x) => x.id == l.id);
    if (i < 0) return;
    layers[i] = l;
    notifyListeners();
  }

  void deleteLayer(String id) {
    layers.removeWhere((PipLayer x) => x.id == id);
    if (selectedOverlayId == id) selectedOverlayId = null;
    notifyListeners();
  }

  // ---------- captions ----------

  List<ClipOverlay> get captions =>
      overlays.where((ClipOverlay o) => o.isCaption).toList();

  void replaceCaptions(List<ClipOverlay> lines) {
    overlays.removeWhere((ClipOverlay o) => o.isCaption);
    overlays.addAll(lines);
    notifyListeners();
  }

  void restyleCaptions({double? sizeFrac, double? cy}) {
    for (int i = 0; i < overlays.length; i++) {
      if (overlays[i].isCaption) {
        overlays[i] = overlays[i].copyWith(sizeFrac: sizeFrac, cy: cy);
      }
    }
    notifyListeners();
  }
}
