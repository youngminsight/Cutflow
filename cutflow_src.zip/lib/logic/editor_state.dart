import 'package:flutter/foundation.dart';

import 'models.dart';

/// The project: an ordered list of segments and which one is selected.
class EditorState extends ChangeNotifier {
  final List<Segment> segments = <Segment>[];
  final List<ClipOverlay> overlays = <ClipOverlay>[];
  final List<AudioTrack> tracks = <AudioTrack>[];
  int selected = -1;
  CropPreset canvas = CropPreset.vertical;
  double originalVolume = 1.0;
  String? selectedOverlayId;
  int _nextId = 1;

  String newId() => '${_nextId++}';

  Segment? get current =>
      (selected >= 0 && selected < segments.length) ? segments[selected] : null;

  int get totalOutputMs =>
      segments.fold<int>(0, (int sum, Segment s) => sum + s.outputMs);

  void add(Segment s) {
    segments.add(s);
    selected = segments.length - 1;
    notifyListeners();
  }

  void select(int index) {
    if (index < 0 || index >= segments.length) return;
    selected = index;
    notifyListeners();
  }

  void updateCurrent(Segment s) {
    if (current == null) return;
    segments[selected] = s;
    notifyListeners();
  }

  /// Splits the selected segment at [positionMs] (a time in the source video).
  /// Returns false if the cut is too close to either end.
  bool splitAt(int positionMs) {
    final Segment? c = current;
    if (c == null) return false;
    if (positionMs - c.startMs < 300 || c.endMs - positionMs < 300) {
      return false;
    }
    segments[selected] = c.copyWith(endMs: positionMs);
    segments.insert(selected + 1, c.copyWith(startMs: positionMs));
    notifyListeners();
    return true;
  }

  void deleteCurrent() {
    if (current == null) return;
    segments.removeAt(selected);
    if (segments.isEmpty) {
      selected = -1;
    } else if (selected >= segments.length) {
      selected = segments.length - 1;
    }
    notifyListeners();
  }

  void moveCurrent(int delta) {
    final int to = selected + delta;
    if (current == null || to < 0 || to >= segments.length) return;
    final Segment s = segments.removeAt(selected);
    segments.insert(to, s);
    selected = to;
    notifyListeners();
  }

  // ---------- time ----------

  /// Time on the final video for a playhead position inside segment [index].
  int globalMsFor(int index, int positionMs) {
    if (index < 0 || index >= segments.length) return 0;
    int sum = 0;
    for (int i = 0; i < index; i++) {
      sum += segments[i].outputMs;
    }
    final Segment s = segments[index];
    final int within = (positionMs - s.startMs).clamp(0, s.trimmedMs).toInt();
    return sum + (within / s.speed).round();
  }

  // ---------- project settings ----------

  void setCanvas(CropPreset p) {
    if (p == CropPreset.original) return;
    canvas = p;
    notifyListeners();
  }

  void setOriginalVolume(double v) {
    originalVolume = v;
    notifyListeners();
  }

  // ---------- overlays ----------

  ClipOverlay? overlayById(String id) {
    for (final ClipOverlay o in overlays) {
      if (o.id == id) return o;
    }
    return null;
  }

  void addOverlay(ClipOverlay o) {
    overlays.add(o);
    selectedOverlayId = o.id;
    notifyListeners();
  }

  void updateOverlay(ClipOverlay o) {
    final int i = overlays.indexWhere((ClipOverlay x) => x.id == o.id);
    if (i < 0) return;
    overlays[i] = o;
    notifyListeners();
  }

  void deleteOverlay(String id) {
    overlays.removeWhere((ClipOverlay x) => x.id == id);
    if (selectedOverlayId == id) selectedOverlayId = null;
    notifyListeners();
  }

  void selectOverlay(String? id) {
    if (selectedOverlayId == id) return;
    selectedOverlayId = id;
    notifyListeners();
  }

  // ---------- audio tracks ----------

  AudioTrack? trackById(String id) {
    for (final AudioTrack t in tracks) {
      if (t.id == id) return t;
    }
    return null;
  }

  void addTrack(AudioTrack t) {
    tracks.add(t);
    notifyListeners();
  }

  void updateTrack(AudioTrack t) {
    final int i = tracks.indexWhere((AudioTrack x) => x.id == t.id);
    if (i < 0) return;
    tracks[i] = t;
    notifyListeners();
  }

  void deleteTrack(String id) {
    tracks.removeWhere((AudioTrack x) => x.id == id);
    notifyListeners();
  }
}
