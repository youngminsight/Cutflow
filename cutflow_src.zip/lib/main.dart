import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

void main() {
  runApp(const CutflowApp());
}

class CutflowApp extends StatelessWidget {
  const CutflowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cutflow',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF22D3EE),
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const HomeScreen(),
    );
  }
}
