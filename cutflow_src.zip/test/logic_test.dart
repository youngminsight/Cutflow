import 'package:cutflow/logic/editor_state.dart';
import 'package:cutflow/logic/export_commands.dart';
import 'package:cutflow/logic/models.dart';
import 'package:flutter_test/flutter_test.dart';

Segment _seg({double speed = 1.0, bool audio = true}) => Segment(
      path: '/tmp/a.mp4',
      sourceMs: 10000,
      hasAudio: audio,
      startMs: 0,
      endMs: 10000,
      speed: speed,
    );

void main() {
  test('split makes two segments and keeps total length', () {
    final EditorState s = EditorState()..add(_seg());
    expect(s.splitAt(4000), isTrue);
    expect(s.segments.length, 2);
    expect(s.segments[0].endMs, 4000);
    expect(s.segments[1].startMs, 4000);
    expect(s.totalOutputMs, 10000);
  });

  test('split too close to the edge is refused', () {
    final EditorState s = EditorState()..add(_seg());
    expect(s.splitAt(100), isFalse);
    expect(s.segments.length, 1);
  });

  test('speed changes output length', () {
    expect(_seg(speed: 2.0).outputMs, 5000);
  });

  test('atempo chain handles big and small speeds', () {
    expect(ExportCommands.atempoChain(1.0), '');
    expect(ExportCommands.atempoChain(4.0), 'atempo=2.0,atempo=2.000');
    expect(ExportCommands.atempoChain(0.25), 'atempo=0.5,atempo=0.500');
  });

  test('canvas sizes are even and correct', () {
    expect(ExportCommands.canvasSize(CropPreset.vertical, 720), <int>[720, 1280]);
    expect(ExportCommands.canvasSize(CropPreset.landscape, 720), <int>[1280, 720]);
    expect(ExportCommands.canvasSize(CropPreset.square, 480), <int>[480, 480]);
  });

  test('silent clips get a generated audio track', () {
    final String cmd = ExportCommands.segmentCommand(
      s: _seg(audio: false),
      outPath: '/tmp/out.mp4',
      width: 720,
      height: 1280,
    );
    expect(cmd.contains('anullsrc'), isTrue);
    final String withAudio = ExportCommands.segmentCommand(
      s: _seg(),
      outPath: '/tmp/out.mp4',
      width: 720,
      height: 1280,
    );
    expect(withAudio.contains('anullsrc'), isFalse);
  });

  test('concat list format', () {
    expect(ExportCommands.concatList(<String>['/a.mp4', '/b.mp4']),
        "file '/a.mp4'\nfile '/b.mp4'");
  });

  test('global time maps through earlier clips and speed', () {
    final EditorState s = EditorState()
      ..add(const Segment(
        path: '/a.mp4',
        sourceMs: 10000,
        hasAudio: true,
        startMs: 0,
        endMs: 4000,
      ))
      ..add(const Segment(
        path: '/b.mp4',
        sourceMs: 10000,
        hasAudio: true,
        startMs: 2000,
        endMs: 8000,
        speed: 2.0,
      ));
    expect(s.globalMsFor(0, 1000), 1000);
    expect(s.globalMsFor(1, 4000), 5000);
  });

  test('final pass mixes overlays and sound', () {
    final String cmd = ExportCommands.finalPassCommand(
      inPath: '/in.mp4',
      outPath: '/out.mp4',
      overlays: const <OverlayInput>[
        OverlayInput(path: '/o.png', x: 10, y: 20, startMs: 1000, endMs: 4000),
      ],
      tracks: const <TrackInput>[
        TrackInput(path: '/m.mp3', delayMs: 500, volume: 0.8),
      ],
      originalVolume: 1.0,
    );
    expect(cmd.contains('overlay=x=10:y=20'), isTrue);
    expect(cmd.contains('amix=inputs=2'), isTrue);
    expect(cmd.contains('adelay=500:all=1'), isTrue);
  });

  test('final pass copies video when there are no overlays', () {
    final String cmd = ExportCommands.finalPassCommand(
      inPath: '/in.mp4',
      outPath: '/out.mp4',
      overlays: const <OverlayInput>[],
      tracks: const <TrackInput>[
        TrackInput(path: '/m.mp3', delayMs: 0, volume: 1.0),
      ],
      originalVolume: 1.0,
    );
    expect(cmd.contains('-c:v copy'), isTrue);
  });

  test('filters are added to the clip command', () {
    final Segment seg = _seg().copyWith(filter: FilterPreset.blackWhite);
    final String cmd = ExportCommands.segmentCommand(
      s: seg,
      outPath: '/tmp/out.mp4',
      width: 720,
      height: 1280,
    );
    expect(cmd.contains('hue=s=0'), isTrue);
  });
}
