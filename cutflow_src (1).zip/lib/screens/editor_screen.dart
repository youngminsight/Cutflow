import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

import '../logic/editor_state.dart';
import '../logic/export_service.dart';
import '../logic/models.dart';
import 'export_sheet.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final EditorState state = EditorState();
  VideoPlayerController? _vc;
  String? _loadedPath;
  int _token = 0;
  bool _busy = false;
  bool _advancing = false;

  @override
  void dispose() {
    _vc?.removeListener(_onTick);
    _vc?.dispose();
    state.dispose();
    super.dispose();
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  // ---------- player ----------

  Future<void> _disposePlayer() async {
    final VideoPlayerController? old = _vc;
    _vc = null;
    _loadedPath = null;
    if (old != null) {
      old.removeListener(_onTick);
      await old.dispose();
    }
  }

  Future<void> _syncPlayer({bool autoplay = false}) async {
    final int my = ++_token;
    final Segment? seg = state.current;
    if (seg == null) {
      await _disposePlayer();
      if (mounted) setState(() {});
      return;
    }
    if (_loadedPath != seg.path) {
      await _disposePlayer();
      final VideoPlayerController fresh =
          VideoPlayerController.file(File(seg.path));
      try {
        await fresh.initialize();
      } catch (e) {
        await fresh.dispose();
        _toast('This video could not be opened.');
        return;
      }
      if (my != _token || !mounted) {
        await fresh.dispose();
        return;
      }
      fresh.addListener(_onTick);
      _vc = fresh;
      _loadedPath = seg.path;
    }
    final VideoPlayerController c = _vc!;
    await c.setPlaybackSpeed(seg.speed);
    await c.seekTo(Duration(milliseconds: seg.startMs));
    if (autoplay) await c.play();
    if (mounted) setState(() {});
  }

  void _onTick() {
    final VideoPlayerController? c = _vc;
    final Segment? seg = state.current;
    if (c == null || seg == null || !c.value.isInitialized) return;
    final int pos = c.value.position.inMilliseconds;
    final bool finished = c.value.isPlaying || c.value.isCompleted;
    if (finished && pos >= seg.endMs - 30 && !_advancing) {
      _advancing = true;
      c.pause();
      final int next = state.selected + 1;
      if (next < state.segments.length) {
        state.select(next);
        _syncPlayer(autoplay: true).whenComplete(() => _advancing = false);
      } else {
        c
            .seekTo(Duration(milliseconds: seg.startMs))
            .whenComplete(() => _advancing = false);
      }
    }
  }

  // ---------- actions ----------

  Future<void> _addClip() async {
    if (_busy) return;
    final XFile? picked =
        await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked == null) return;
    setState(() => _busy = true);
    try {
      final VideoPlayerController probe =
          VideoPlayerController.file(File(picked.path));
      await probe.initialize();
      final int ms = probe.value.duration.inMilliseconds;
      await probe.dispose();
      if (ms < 500) {
        _toast('That video is too short.');
        return;
      }
      final bool audio = await MediaProbe.hasAudio(picked.path);
      state.add(Segment(
        path: picked.path,
        sourceMs: ms,
        hasAudio: audio,
        startMs: 0,
        endMs: ms,
      ));
      await _syncPlayer();
    } catch (e) {
      _toast('Could not add that video: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _split() {
    final VideoPlayerController? c = _vc;
    if (c == null) return;
    final int pos = c.value.position.inMilliseconds;
    if (!state.splitAt(pos)) {
      _toast('Move the playhead into the clip first, away from the ends.');
      return;
    }
    _syncPlayer();
  }

  void _delete() {
    state.deleteCurrent();
    _syncPlayer();
  }

  void _rotate() {
    final Segment? seg = state.current;
    if (seg == null) return;
    state.updateCurrent(seg.copyWith(rotation: (seg.rotation + 90) % 360));
  }

  Future<void> _pickSpeed() async {
    final Segment? seg = state.current;
    if (seg == null) return;
    final double? v = await showModalBottomSheet<double>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (final double s in kSpeeds)
                ChoiceChip(
                  label: Text('${s}x'),
                  selected: s == seg.speed,
                  onSelected: (_) => Navigator.pop(ctx, s),
                ),
            ],
          ),
        ),
      ),
    );
    if (v != null) {
      state.updateCurrent(seg.copyWith(speed: v));
      await _vc?.setPlaybackSpeed(v);
    }
  }

  Future<void> _pickCrop() async {
    final Segment? seg = state.current;
    if (seg == null) return;
    final CropPreset? v = await showModalBottomSheet<CropPreset>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (final CropPreset p in CropPreset.values)
                ChoiceChip(
                  label: Text(p.label),
                  selected: p == seg.crop,
                  onSelected: (_) => Navigator.pop(ctx, p),
                ),
            ],
          ),
        ),
      ),
    );
    if (v != null) state.updateCurrent(seg.copyWith(crop: v));
  }

  Future<void> _openExport() async {
    await _vc?.pause();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext ctx) =>
          ExportSheet(segments: List<Segment>.of(state.segments)),
    );
  }

  // ---------- screens ----------

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (BuildContext context, Widget? child) {
        final Segment? seg = state.current;
        return Scaffold(
          appBar: AppBar(
            title: const Text('New project'),
            actions: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: FilledButton(
                  onPressed:
                      (state.segments.isEmpty || _busy) ? null : _openExport,
                  child: const Text('Export'),
                ),
              ),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: <Widget>[
                if (_busy) const LinearProgressIndicator(),
                Expanded(
                  child: seg == null ? _emptyState() : _editor(seg),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _emptyState() {
    final ThemeData theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.video_library_rounded,
                size: 56, color: theme.colorScheme.primary),
            const SizedBox(height: 16),
            Text(
              'Add your first video',
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              'Pick a video from your gallery to start editing.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _busy ? null : _addClip,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Add video'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _preview(Segment seg) {
    final VideoPlayerController? c = _vc;
    if (c == null || !c.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }
    final Size size = c.value.size;
    Widget video = RotatedBox(
      quarterTurns: seg.rotation ~/ 90,
      child: SizedBox(
        width: size.width,
        height: size.height,
        child: VideoPlayer(c),
      ),
    );
    final double? ratio = seg.crop.ratio;
    if (ratio != null) {
      video = AspectRatio(
        aspectRatio: ratio,
        child: ClipRect(child: FittedBox(fit: BoxFit.cover, child: video)),
      );
    } else {
      video = FittedBox(fit: BoxFit.contain, child: video);
    }
    return Center(child: video);
  }

  Widget _editor(Segment seg) {
    final ThemeData theme = Theme.of(context);
    final VideoPlayerController? c = _vc;
    return Column(
      children: <Widget>[
        Expanded(child: _preview(seg)),
        if (c != null && c.value.isInitialized)
          ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: c,
            builder: (BuildContext context, VideoPlayerValue v, Widget? w) {
              final int pos = (v.position.inMilliseconds - seg.startMs)
                  .clamp(0, seg.trimmedMs)
                  .toInt();
              return Row(
                children: <Widget>[
                  IconButton(
                    iconSize: 40,
                    icon: Icon(v.isPlaying
                        ? Icons.pause_circle_filled_rounded
                        : Icons.play_circle_filled_rounded),
                    onPressed: () {
                      if (v.isPlaying) {
                        c.pause();
                      } else {
                        final int p = v.position.inMilliseconds;
                        if (p >= seg.endMs - 50 || p < seg.startMs) {
                          c.seekTo(Duration(milliseconds: seg.startMs));
                        }
                        c.play();
                      }
                    },
                  ),
                  Text('${formatMs(pos)} / ${formatMs(seg.trimmedMs)}'),
                  Expanded(
                    child: Slider(
                      value: pos.toDouble(),
                      min: 0,
                      max: seg.trimmedMs.toDouble(),
                      onChanged: (double x) => c.seekTo(
                        Duration(milliseconds: seg.startMs + x.round()),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text('Trim: start ${formatMs(seg.startMs)}',
                  style: theme.textTheme.bodySmall),
              Text('end ${formatMs(seg.endMs)}',
                  style: theme.textTheme.bodySmall),
            ],
          ),
        ),
        RangeSlider(
          min: 0,
          max: seg.sourceMs.toDouble(),
          values: RangeValues(seg.startMs.toDouble(), seg.endMs.toDouble()),
          onChanged: (RangeValues v) {
            final int s = v.start.round();
            final int e = v.end.round();
            if (e - s < 500) return;
            state.updateCurrent(seg.copyWith(startMs: s, endMs: e));
          },
          onChangeEnd: (RangeValues v) {
            _vc?.seekTo(Duration(milliseconds: v.start.round()));
          },
        ),
        _timeline(),
        const SizedBox(height: 6),
        _toolbar(seg),
        const SizedBox(height: 6),
      ],
    );
  }

  Widget _timeline() {
    final ColorScheme cs = Theme.of(context).colorScheme;
    return SizedBox(
      height: 62,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: state.segments.length,
        separatorBuilder: (BuildContext context, int index) =>
            const SizedBox(width: 6),
        itemBuilder: (BuildContext context, int i) {
          final Segment s = state.segments[i];
          final bool sel = i == state.selected;
          final double w = (s.outputMs / 1000 * 14).clamp(84.0, 220.0).toDouble();
          return GestureDetector(
            onTap: () {
              state.select(i);
              _syncPlayer();
            },
            child: Container(
              width: w,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: sel
                    ? cs.primary.withOpacity(0.25)
                    : const Color(0xFF1C1C1E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: sel ? cs.primary : Colors.white12,
                  width: sel ? 2 : 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text('Clip ${i + 1}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(
                    s.speed == 1.0
                        ? formatMs(s.outputMs)
                        : '${formatMs(s.outputMs)}  ${s.speed}x',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _toolbar(Segment seg) {
    return SizedBox(
      height: 64,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: <Widget>[
          _Tool(Icons.add_rounded, 'Add', _busy ? null : _addClip),
          _Tool(Icons.call_split_rounded, 'Split', _split),
          _Tool(Icons.delete_outline_rounded, 'Delete', _delete),
          _Tool(Icons.arrow_back_rounded, 'Move left',
              () => state.moveCurrent(-1)),
          _Tool(Icons.arrow_forward_rounded, 'Move right',
              () => state.moveCurrent(1)),
          _Tool(Icons.speed_rounded, '${seg.speed}x', _pickSpeed),
          _Tool(Icons.rotate_90_degrees_cw_rounded, 'Rotate', _rotate),
          _Tool(Icons.crop_rounded, 'Crop', _pickCrop),
        ],
      ),
    );
  }
}

class _Tool extends StatelessWidget {
  const _Tool(this.icon, this.label, this.onTap);

  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: SizedBox(
        width: 76,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: onTap == null ? Colors.white24 : null),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
