import 'package:flutter/foundation.dart';

import 'models.dart';

/// The project: an ordered list of segments and which one is selected.
class EditorState extends ChangeNotifier {
  final List<Segment> segments = <Segment>[];
  int selected = -1;

  Segment? get current =>
      (selected >= 0 && selected < segments.length) ? segments[selected] : null;

  int get totalOutputMs =>
      segments.fold<int>(0, (int sum, Segment s) => sum + s.outputMs);

  void add(Segment s) {
    segments.add(s);
    selected = segments.length - 1;
    notifyListeners();
  }

  void select(int index) {
    if (index < 0 || index >= segments.length) return;
    selected = index;
    notifyListeners();
  }

  void updateCurrent(Segment s) {
    if (current == null) return;
    segments[selected] = s;
    notifyListeners();
  }

  /// Splits the selected segment at [positionMs] (a time in the source video).
  /// Returns false if the cut is too close to either end.
  bool splitAt(int positionMs) {
    final Segment? c = current;
    if (c == null) return false;
    if (positionMs - c.startMs < 300 || c.endMs - positionMs < 300) {
      return false;
    }
    segments[selected] = c.copyWith(endMs: positionMs);
    segments.insert(selected + 1, c.copyWith(startMs: positionMs));
    notifyListeners();
    return true;
  }

  void deleteCurrent() {
    if (current == null) return;
    segments.removeAt(selected);
    if (segments.isEmpty) {
      selected = -1;
    } else if (selected >= segments.length) {
      selected = segments.length - 1;
    }
    notifyListeners();
  }

  void moveCurrent(int delta) {
    final int to = selected + delta;
    if (current == null || to < 0 || to >= segments.length) return;
    final Segment s = segments.removeAt(selected);
    segments.insert(to, s);
    selected = to;
    notifyListeners();
  }
}
