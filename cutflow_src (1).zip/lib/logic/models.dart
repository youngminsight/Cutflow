/// Crop shapes, also used as export canvas shapes.
enum CropPreset { original, vertical, square, landscape, portrait }

extension CropPresetInfo on CropPreset {
  String get label => switch (this) {
        CropPreset.original => 'Original',
        CropPreset.vertical => '9:16 Vertical',
        CropPreset.square => '1:1 Square',
        CropPreset.landscape => '16:9 Wide',
        CropPreset.portrait => '4:5 Portrait',
      };

  /// width / height, or null for "keep as it is".
  double? get ratio => switch (this) {
        CropPreset.original => null,
        CropPreset.vertical => 9 / 16,
        CropPreset.square => 1.0,
        CropPreset.landscape => 16 / 9,
        CropPreset.portrait => 4 / 5,
      };
}

const List<double> kSpeeds = <double>[0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0];

/// One piece of the timeline: part of a source video plus its settings.
class Segment {
  const Segment({
    required this.path,
    required this.sourceMs,
    required this.hasAudio,
    required this.startMs,
    required this.endMs,
    this.speed = 1.0,
    this.rotation = 0,
    this.crop = CropPreset.original,
  });

  final String path;
  final int sourceMs;
  final bool hasAudio;
  final int startMs;
  final int endMs;
  final double speed;
  final int rotation; // 0, 90, 180 or 270 degrees clockwise
  final CropPreset crop;

  int get trimmedMs => endMs - startMs;

  /// Length of this piece in the finished video (after speed change).
  int get outputMs => (trimmedMs / speed).round();

  Segment copyWith({
    int? startMs,
    int? endMs,
    double? speed,
    int? rotation,
    CropPreset? crop,
  }) {
    return Segment(
      path: path,
      sourceMs: sourceMs,
      hasAudio: hasAudio,
      startMs: startMs ?? this.startMs,
      endMs: endMs ?? this.endMs,
      speed: speed ?? this.speed,
      rotation: rotation ?? this.rotation,
      crop: crop ?? this.crop,
    );
  }
}

String formatMs(int ms) {
  final int total = (ms / 1000).round();
  final int m = total ~/ 60;
  final int s = total % 60;
  return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
}
