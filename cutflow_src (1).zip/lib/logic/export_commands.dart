import 'models.dart';

/// Builds the FFmpeg command text. Pure Dart, so it can be unit tested.
class ExportCommands {
  ExportCommands._();

  static int _even(double v) {
    final int i = v.round();
    return i - (i % 2);
  }

  /// Output size for a canvas shape. [shortSide] is 480, 720 or 1080.
  static List<int> canvasSize(CropPreset canvas, int shortSide) {
    final double a = canvas.ratio ?? (16 / 9);
    if (a >= 1) {
      return <int>[_even(shortSide * a), shortSide];
    }
    return <int>[shortSide, _even(shortSide / a)];
  }

  /// FFmpeg's atempo only accepts 0.5 to 2.0, so bigger/smaller speeds chain.
  static String atempoChain(double speed) {
    if ((speed - 1.0).abs() < 0.001) return '';
    final List<String> parts = <String>[];
    double s = speed;
    while (s > 2.0) {
      parts.add('atempo=2.0');
      s /= 2.0;
    }
    while (s < 0.5) {
      parts.add('atempo=0.5');
      s /= 0.5;
    }
    parts.add('atempo=${s.toStringAsFixed(3)}');
    return parts.join(',');
  }

  /// Renders one segment into a standard-format MP4 (same size, 30 fps,
  /// AAC audio) so all pieces can be joined without re-encoding.
  static String segmentCommand({
    required Segment s,
    required String outPath,
    required int width,
    required int height,
  }) {
    final String ss = (s.startMs / 1000).toStringAsFixed(3);
    final String dur = (s.trimmedMs / 1000).toStringAsFixed(3);
    final String outDur = (s.outputMs / 1000).toStringAsFixed(3);
    final String sp = s.speed.toStringAsFixed(4);

    final List<String> vf = <String>[];
    switch (s.rotation % 360) {
      case 90:
        vf.add('transpose=1');
        break;
      case 180:
        vf.add('transpose=1');
        vf.add('transpose=1');
        break;
      case 270:
        vf.add('transpose=2');
        break;
      default:
        break;
    }
    final double? r = s.crop.ratio;
    if (r != null) {
      final String rs = r.toStringAsFixed(6);
      vf.add("crop=w='trunc(min(iw,ih*$rs)/2)*2':h='trunc(min(ih,iw/$rs)/2)*2'");
    }
    vf.add('setpts=PTS/$sp');
    vf.add('scale=$width:$height:force_original_aspect_ratio=decrease:force_divisible_by=2');
    vf.add('pad=$width:$height:(ow-iw)/2:(oh-ih)/2:color=black');
    vf.add('setsar=1');
    vf.add('fps=30');
    vf.add('format=yuv420p');

    final String tempo = atempoChain(s.speed);
    final String af = tempo.isEmpty ? 'aresample=44100' : '$tempo,aresample=44100';

    final StringBuffer b = StringBuffer('-y -ss $ss -t $dur -i "${s.path}" ');
    if (!s.hasAudio) {
      b.write('-f lavfi -t $outDur -i anullsrc=channel_layout=stereo:sample_rate=44100 ');
    }
    b.write('-map 0:v:0 ');
    b.write(s.hasAudio ? '-map 0:a:0 ' : '-map 1:a:0 ');
    b.write('-vf "${vf.join(',')}" -af "$af" ');
    b.write('-c:v libx264 -preset superfast -crf 25 -pix_fmt yuv420p ');
    b.write('-c:a aac -b:a 128k -ar 44100 -ac 2 ');
    b.write('-t $outDur "$outPath"');
    return b.toString();
  }

  static String concatList(List<String> paths) {
    return paths.map((String p) => "file '$p'").join('\n');
  }
}
